-- ============================================================================
-- Elemental_Shammy - MAIN
-- ============================================================================
-- Author: BLIZZ
-- Version: 2.8
-- Folder: Elemental_Shammy_v2.8
-- Standalone IZI. No FB_Nexus.
-- ============================================================================

local PLUGIN_MODULES = {
    "ui",
    "spells",
    "gui",
    "targeting",
    "rotation",
}

for i = 1, #PLUGIN_MODULES do
    package.loaded[PLUGIN_MODULES[i]] = nil
end

---@type izi_api
local izi = require("common/izi_sdk")

---@type movement_handler
local movement_handler = require("common/utility/movement_handler")

local gui = require("gui")
local rotation = require("rotation")

_G.Elemental_Shammy = _G.Elemental_Shammy or {}
local NS = _G.Elemental_Shammy

NS.meta = NS.meta or {
    name    = "Elemental_Shammy",
    version = "2.8",
    author  = "BLIZZ",
}

if type(NS.session) ~= "number" then
    NS.session = 1
end

local MY_SESSION = NS.session

local function is_stale()
    return NS.session ~= MY_SESSION
end

local function on_update()
    if is_stale() then
        return
    end

    pcall(function()
        izi.on_update()
    end)

    pcall(function()
        gui.process_keybinds()
    end)

    rotation.tick()
end

local function on_render()
    if is_stale() then
        return
    end

    if not gui.is_on("movement") then
        pcall(function()
            movement_handler:resume_movement()
            movement_handler:unlock_look_at()
        end)
        return
    end

    pcall(function()
        movement_handler:on_render()
    end)
end

local function on_render_window()
    if is_stale() then
        return
    end
    gui.draw()
end

core.register_on_update_callback(on_update)
core.register_on_render_callback(on_render)
core.register_on_render_window_callback(on_render_window)

core.log(string.format("[Elemental_Shammy] v%s loaded by %s", NS.meta.version, NS.meta.author or "BLIZZ"))
