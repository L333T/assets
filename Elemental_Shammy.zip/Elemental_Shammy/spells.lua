-- ============================================================================
-- Elemental_Shammy - SPELLS
-- ============================================================================
-- Purpose: Fixed TBC IDs, IZI spell/item wrappers, totem queue helpers.
-- Author: BLIZZ
-- Version: 2.8
-- Folder: Elemental_Shammy_v2.8
-- ============================================================================

---@type izi_api
local izi = require("common/izi_sdk")

---@type spell_queue
local spell_queue = require("common/modules/spell_queue")

---@type buff_manager
local buff_manager = require("common/modules/buff_manager")

---@type movement_handler
local movement_handler = require("common/utility/movement_handler")

local gui = require("gui")

---@type enums
local enums = require("common/enums")

local spells = {}

spells.QUEUE_PRIORITY = 1
spells.TOTEM_SLOTS = 4
spells.TOTEM_CONFIRM_S = 1.0

spells.ids = {
    lightning_shield       = 25472,
    lightning_shield_buff  = 25472,
    totem_of_wrath         = 307306,
    totem_of_wrath_buff    = 307308,
    mana_spring            = 25570,
    mana_spring_buff       = 25569,
    wrath_of_air           = 3738,
    wrath_of_air_buff      = 2895,
    tremor                 = 8143,
    elemental_mastery      = 16166,
    elemental_mastery_buff = 16166,
    chain_lightning        = 25442,
    lightning_bolt         = 25449,
    flame_shock            = 25457,
    healing_wave           = 25396,
    chain_heal             = 25423,
    lesser_healing_wave    = 25420,
    drums_of_battle        = 29529,
    master_healthstone     = 22105,
    purge                  = 8012,
    earth_shock_r1         = 8042,
    earth_shock            = 25454,
    frost_shock            = 25464,
    violet_eye             = 28727,
    enlightenment          = 29601,
    gift_of_the_naaru      = 28880,
    gift_of_the_naaru_buff = 28880,
}

spells.VIOLET_EYE_SLOT = 12
spells.LIGHTNING_SHIELD_BUFFS = { 25472, 25469, 10432, 10431, 8134, 945, 905, 325, 324 }
spells.FLAME_SHOCK_DEBUFFS = { 25457, 29228, 10448, 10447, 8050, 8049, 8048 }
spells.FLAME_SHOCK_REFRESH_S = 3.0

local function safe(fn)
    local ok, result = pcall(fn)
    if ok then
        return result
    end
    return nil
end

spells.safe = safe

spells.lightning_shield    = izi.spell(25472, 25469, 10432, 10431, 8134, 945, 905, 325, 324)
spells.totem_of_wrath      = izi.spell(307306, 30706)
spells.mana_spring         = izi.spell(spells.ids.mana_spring)
spells.wrath_of_air        = izi.spell(spells.ids.wrath_of_air)
spells.tremor              = izi.spell(spells.ids.tremor)
spells.elemental_mastery   = izi.spell(spells.ids.elemental_mastery)
spells.chain_lightning     = izi.spell(spells.ids.chain_lightning)
spells.lightning_bolt      = izi.spell(spells.ids.lightning_bolt)
spells.flame_shock         = izi.spell(25457, 29228, 10448, 10447, 8050, 8049, 8048)
spells.healing_wave        = izi.spell(spells.ids.healing_wave)
spells.chain_heal          = izi.spell(spells.ids.chain_heal)
spells.lesser_healing_wave = izi.spell(spells.ids.lesser_healing_wave)
spells.drums_of_battle     = izi.item(spells.ids.drums_of_battle)
spells.master_healthstone  = izi.item(spells.ids.master_healthstone)
spells.purge               = izi.spell(spells.ids.purge)
spells.earth_shock_r1      = izi.spell(spells.ids.earth_shock_r1)
spells.earth_shock         = izi.spell(spells.ids.earth_shock)
spells.frost_shock         = izi.spell(spells.ids.frost_shock)
spells.violet_eye          = izi.item(spells.ids.violet_eye)
spells.gift_of_the_naaru   = izi.spell(spells.ids.gift_of_the_naaru)

spells.lightning_shield:track_buff(spells.LIGHTNING_SHIELD_BUFFS)
spells.flame_shock:track_debuff(spells.FLAME_SHOCK_DEBUFFS)
spells.gift_of_the_naaru:track_buff(spells.ids.gift_of_the_naaru_buff)
spells.totem_of_wrath:track_buff({ 307308, 30708 })
spells.mana_spring:track_buff(spells.ids.mana_spring_buff)
spells.wrath_of_air:track_buff(spells.ids.wrath_of_air_buff)
spells.elemental_mastery:track_buff(spells.ids.elemental_mastery_buff)

local last_totem_cast = {}

local function tremor_name()
    local name = safe(function()
        return core.spell_book.get_spell_name(spells.ids.tremor)
    end)
    if type(name) == "string" and name ~= "" then
        return name
    end
    return "Tremor Totem"
end

function spells.cast_unit(spell, target, message, extra_opts)
    if not spell or not target then
        return false
    end

    local opts = extra_opts or {}

    local cast_time = safe(function() return spell:cast_time() end)
    if type(cast_time) == "number" and cast_time > 0.05 and gui.is_on("movement") then
        pcall(function()
            movement_handler:look_at_target(cast_time + 0.2, nil, target)
            movement_handler:pause_movement_light(cast_time + 0.2)
        end)
    end

    local ok = safe(function()
        return spell:cast_safe(target, message, opts)
    end)
    return ok == true
end

function spells.cast_self(spell, player, message, extra_opts)
    if not spell or not player then
        return false
    end

    local opts = extra_opts or {}
    opts.skip_range = true
    opts.skip_facing = true

    local ok = safe(function()
        return spell:cast_safe(player, message, opts)
    end)
    return ok == true
end

local TOTEM_CAST_OPTS = {
    skip_moving = true,
    skip_range = true,
    skip_facing = true,
}

function spells.place_totem(spell, player, key, message)
    if not spell or not player then
        return false
    end

    local now = core.time()
    local last = last_totem_cast[key]
    if type(last) == "number" and (now - last) < spells.TOTEM_CONFIRM_S then
        return false
    end

    local self_cast = safe(function()
        return spell:cast_safe(player, message, TOTEM_CAST_OPTS)
    end)
    if self_cast == true then
        last_totem_cast[key] = now
        return true
    end

    local id = safe(function()
        return spell:id()
    end)
    if type(id) ~= "number" or id <= 0 then
        return false
    end

    local queued_self = safe(function()
        spell_queue:queue_spell_target(id, player, spells.QUEUE_PRIORITY, message, true)
        return true
    end)
    if queued_self == true then
        last_totem_cast[key] = now
        return true
    end

    return false
end

function spells.has_player_buff(player, buff_id)
    if not player then
        return false
    end
    local ok = safe(function()
        return player:has_buff(buff_id)
    end)
    return ok == true
end

---True when the given buff ID is visible on the player.
---@param player game_object
---@param buff_id number
---@return boolean
function spells.player_has_visible_buff(player, buff_id)
    if not player or type(buff_id) ~= "number" then
        return false
    end

    local has_buff = safe(function()
        return player:has_buff(buff_id)
    end)
    if has_buff == true then
        return true
    end

    local has_aura = safe(function()
        return player:has_aura(buff_id)
    end)
    if has_aura == true then
        return true
    end

    local data = safe(function()
        return buff_manager:get_buff_data(player, { buff_id })
    end)
    if type(data) == "table" and data.is_active == true then
        return true
    end

    return false
end

---True when any of the given buff IDs is visible on the player.
---@param player game_object
---@param buff_ids number[]
---@return boolean
function spells.player_has_any_visible_buff(player, buff_ids)
    if not player or type(buff_ids) ~= "table" then
        return false
    end

    local has_buff = safe(function()
        return player:has_buff(buff_ids)
    end)
    if has_buff == true then
        return true
    end

    local has_aura = safe(function()
        return player:has_aura(buff_ids)
    end)
    if has_aura == true then
        return true
    end

    local data = safe(function()
        return buff_manager:get_buff_data(player, buff_ids)
    end)
    if type(data) == "table" and data.is_active == true then
        return true
    end

    for i = 1, #buff_ids do
        if spells.player_has_visible_buff(player, buff_ids[i]) then
            return true
        end
    end

    return false
end

local function lightning_shield_keys()
    local db = enums.buff_db
    if type(db) == "table" and db.LIGHTNING_SHIELD ~= nil then
        return db.LIGHTNING_SHIELD
    end
    return spells.LIGHTNING_SHIELD_BUFFS
end

local function flame_shock_keys()
    local db = enums.buff_db
    if type(db) == "table" and db.FLAME_SHOCK ~= nil then
        return db.FLAME_SHOCK
    end
    return spells.FLAME_SHOCK_DEBUFFS
end

---True when Lightning Shield is on the player.
---@param player game_object
---@return boolean
function spells.player_has_lightning_shield(player)
    if not player then
        return false
    end

    local data = safe(function()
        return buff_manager:get_buff_data(player, lightning_shield_keys())
    end)
    if type(data) == "table" and data.is_active == true then
        return true
    end

    return spells.player_has_any_visible_buff(player, spells.LIGHTNING_SHIELD_BUFFS)
end

---True when Flame Shock is missing or about to fall off the enemy.
---@param target game_object
---@return boolean
function spells.flame_shock_needs_refresh(target)
    if not target then
        return false
    end

    local remains = safe(function()
        return target:debuff_remains(flame_shock_keys())
    end)
    if type(remains) == "number" then
        return remains < spells.FLAME_SHOCK_REFRESH_S
    end

    local data = safe(function()
        return buff_manager:get_debuff_data(target, flame_shock_keys())
    end)
    if type(data) == "table" then
        if data.is_active ~= true then
            return true
        end
        if type(data.remaining) == "number" then
            local rem_sec = data.remaining > 20 and (data.remaining / 1000) or data.remaining
            return rem_sec < spells.FLAME_SHOCK_REFRESH_S
        end
    end

    return true
end

---True when Gift of the Naaru HoT 28880 is on the player.
---@param player game_object
---@return boolean
function spells.player_has_gift_of_the_naaru(player)
    return spells.player_has_visible_buff(player, spells.ids.gift_of_the_naaru_buff)
end

---TBC food/water auras. Used if enums.buff_db.EATING_OR_DRINKING is empty at runtime.
local EAT_DRINK_AURAS = {
    430, 431, 432, 433,
    434, 435, 436,
    27089, 27088, 27087, 27086, 27085, 27084,
    27083, 27082, 27081, 27080,
    33722, 33717, 33042, 29007,
    10250, 22734, 25696, 28616, 33254, 34291,
    43706, 43763, 46755,
    1127, 1129, 1131, 1133, 1135, 1137,
}

local function aura_list_is_active(player, spec)
    if not player or type(spec) ~= "table" or #spec == 0 then
        return false
    end

    local data = safe(function()
        return buff_manager:get_aura_data(player, spec)
    end)
    if type(data) == "table" and data.is_active == true then
        return true
    end

    local has_aura = safe(function()
        return player:has_aura(spec)
    end)
    if has_aura == true then
        return true
    end

    local has_buff = safe(function()
        return player:has_buff(spec)
    end)
    return has_buff == true
end

---True while sitting with a Food or Drink buff. Combat and movement cancel it.
---@param player game_object
---@return boolean
function spells.player_is_eating_or_drinking(player)
    if not player then
        return false
    end
    if safe(function() return player:is_moving() end) == true then
        return false
    end
    if safe(function() return player:is_in_combat() end) == true then
        return false
    end

    local db = enums.buff_db
    if type(db) == "table" then
        if aura_list_is_active(player, db.EATING_OR_DRINKING) then
            return true
        end
        if aura_list_is_active(player, db.EATING) then
            return true
        end
        if aura_list_is_active(player, db.DRINKING) then
            return true
        end
    end

    return aura_list_is_active(player, EAT_DRINK_AURAS)
end

function spells.spell_is_learned(spell, spell_id)
    if spell then
        local learned = safe(function()
            return spell:is_learned()
        end)
        if learned == true then
            return true
        end
        local available = safe(function()
            return spell:is_available()
        end)
        if available == true then
            return true
        end
    end
    if type(spell_id) == "number" then
        local book = safe(function()
            return core.spell_book.is_spell_learned(spell_id)
        end)
        if book == true then
            return true
        end
        local owned = safe(function()
            return core.spell_book.has_spell(spell_id)
        end)
        if owned == true then
            return true
        end
    end
    return false
end

function spells.totem_active_by_name(wanted)
    if type(wanted) ~= "string" or wanted == "" then
        return false
    end

    for index = 1, spells.TOTEM_SLOTS do
        local info = safe(function()
            return core.spell_book.get_totem_info(index)
        end)
        if type(info) == "table" and info.have_totem == true then
            local totem_name = info.totem_name
            if type(totem_name) == "string" and totem_name ~= "" then
                if totem_name == wanted then
                    return true
                end
            end
        end
    end

    return false
end

function spells.tremor_active()
    return spells.totem_active_by_name(tremor_name())
end

local function spell_totem_name(spell, fallback)
    if spell then
        local name = safe(function() return spell:name() end)
        if type(name) == "string" and name ~= "" then
            return name
        end
    end
    return fallback
end

---Recast only when the player buff is not visible and the totem is not already down.
---@param player game_object
---@param buff_spec number|number[]|nil
---@param spell izi_spell|nil
---@param fallback_name string
---@return boolean
function spells.totem_needs_recast(player, buff_spec, spell, fallback_name)
    if type(buff_spec) == "number" then
        if spells.player_has_visible_buff(player, buff_spec) then
            return false
        end
    elseif type(buff_spec) == "table" then
        for i = 1, #buff_spec do
            if spells.player_has_visible_buff(player, buff_spec[i]) then
                return false
            end
        end
    end

    local names = { fallback_name, spell_totem_name(spell, fallback_name) }
    for i = 1, #names do
        if type(names[i]) == "string" and names[i] ~= "" then
            if spells.totem_active_by_name(names[i]) then
                return false
            end
        end
    end
    return true
end

function spells.combat_totems_ready(player)
    if spells.totem_needs_recast(player, { 307308, 30708 }, spells.totem_of_wrath, "Totem of Wrath") then
        return false
    end
    if spells.totem_needs_recast(player, spells.ids.wrath_of_air_buff, spells.wrath_of_air, "Wrath of Air Totem") then
        return false
    end
    if spells.totem_needs_recast(player, spells.ids.mana_spring_buff, spells.mana_spring, "Mana Spring Totem") then
        return false
    end
    if spells.totem_needs_recast(player, nil, spells.tremor, "Tremor Totem") then
        return false
    end
    return true
end

function spells.use_drums(player)
    local item_id = spells.ids.drums_of_battle

    if player then
        local cooldown = safe(function()
            return player:get_item_cooldown(item_id)
        end)
        if type(cooldown) == "number" and cooldown > 0 then
            return false
        end
    end

    local item = spells.drums_of_battle
    if not item then
        item = safe(function()
            return izi.item(item_id)
        end)
        spells.drums_of_battle = item
    end

    if item then
        local used = safe(function()
            return item:use_self_safe("Drums of Battle")
        end)
        if used == true then
            return true
        end
    end

    local queued = safe(function()
        spell_queue:queue_item_self(item_id, spells.QUEUE_PRIORITY, "Drums of Battle")
        return true
    end)
    if queued == true then
        return true
    end

    if player then
        local used_raw = safe(function()
            return core.input.use_item(item_id)
        end)
        if used_raw == true then
            return true
        end
    end

    return false
end

---True when Master Healthstone (22105) is in bags and off cooldown.
---@param player game_object
---@return boolean
function spells.healthstone_ready(player)
    local item_id = spells.ids.master_healthstone
    local item = spells.master_healthstone
    if not item then
        item = safe(function()
            return izi.item(item_id)
        end)
        spells.master_healthstone = item
    end

    local has_item = safe(function()
        return player:has_item(item_id)
    end)
    if has_item ~= true then
        if not item then
            return false
        end
        local in_bags = safe(function()
            return item:in_inventory()
        end)
        if in_bags ~= true then
            return false
        end
        local count = safe(function()
            return item:count()
        end)
        if type(count) == "number" and count <= 0 then
            return false
        end
    end

    if item then
        local ready = safe(function()
            return item:cooldown_up()
        end)
        if ready == false then
            return false
        end
        local usable = safe(function()
            return item:is_usable()
        end)
        if usable == false then
            return false
        end
    end

    local cooldown = safe(function()
        return player:get_item_cooldown(item_id)
    end)
    if type(cooldown) == "number" and cooldown > 0 then
        return false
    end

    return true
end

function spells.use_healthstone(player)
    if not spells.healthstone_ready(player) then
        return false
    end

    local item_id = spells.ids.master_healthstone
    local item = spells.master_healthstone
    local item_opts = {
        skip_gcd = true,
        skip_casting = true,
        skip_channeling = true,
        skip_moving = true,
    }

    if item then
        local used = safe(function()
            return item:use_self_safe("Master Healthstone", item_opts)
        end)
        if used == true then
            return true
        end
    end

    local queued = safe(function()
        spell_queue:queue_item_self_fast(item_id, spells.QUEUE_PRIORITY, "Master Healthstone")
        return true
    end)
    if queued == true then
        return true
    end

    local used_raw = safe(function()
        return core.input.use_item(item_id)
    end)
    return used_raw == true
end

---Use best health potion available in bags.
---@param player game_object
---@return boolean
function spells.use_best_health_potion(player)
    local item_opts = {
        skip_gcd = true,
        skip_casting = true,
        skip_channeling = true,
        skip_moving = true,
    }
    local used = safe(function()
        return izi.use_best_health_potion_safe(item_opts)
    end)
    return used == true
end

---Use best mana potion available in bags.
---@param player game_object
---@return boolean
function spells.use_best_mana_potion(player)
    local item_opts = {
        skip_gcd = true,
        skip_casting = true,
        skip_channeling = true,
        skip_moving = true,
    }
    local used = safe(function()
        return izi.use_best_mana_potion_safe(item_opts)
    end)
    return used == true
end

---True when Enlightenment (29601) from Pendant of the Violet Eye is on the player.
---@param player game_object
---@return boolean
function spells.player_has_enlightenment(player)
    return spells.player_has_visible_buff(player, spells.ids.enlightenment)
end

local function item_id_in_slot(player, slot)
    if not player or type(slot) ~= "number" then
        return nil
    end

    local info = safe(function()
        return player:get_item_at_inventory_slot(slot)
    end)
    if type(info) ~= "table" or not info.object then
        return nil
    end

    local id = safe(function()
        return info.object:get_item_id()
    end)
    if type(id) == "number" and id > 0 then
        return id
    end
    return nil
end

---True when Pendant of the Violet Eye (28727) is equipped, preferring slot 12.
---@param player game_object
---@return boolean
function spells.violet_eye_equipped(player)
    if item_id_in_slot(player, spells.VIOLET_EYE_SLOT) == spells.ids.violet_eye then
        return true
    end

    local item = spells.violet_eye
    if not item then
        return false
    end

    local equipped = safe(function()
        return item:equipped()
    end)
    if equipped == true then
        return true
    end

    local slot = safe(function()
        return item:equipped_slot()
    end)
    return slot == spells.VIOLET_EYE_SLOT
end

---True when the trinket is equipped and off cooldown.
---@param player game_object
---@return boolean
function spells.violet_eye_ready(player)
    if not spells.violet_eye_equipped(player) then
        return false
    end

    local item = spells.violet_eye
    if item then
        local ready = safe(function()
            return item:cooldown_up()
        end)
        if ready == true then
            return true
        end
        if ready == false then
            return false
        end
    end

    local cooldown = safe(function()
        return player:get_item_cooldown(spells.ids.violet_eye)
    end)
    if type(cooldown) == "number" then
        return cooldown <= 0
    end

    return true
end

function spells.use_violet_eye(player)
    local item_id = spells.ids.violet_eye
    if not spells.violet_eye_equipped(player) then
        return false
    end

    if player then
        local cooldown = safe(function()
            return player:get_item_cooldown(item_id)
        end)
        if type(cooldown) == "number" and cooldown > 0 then
            return false
        end
    end

    local item = spells.violet_eye
    if not item then
        item = safe(function()
            return izi.item(item_id)
        end)
        spells.violet_eye = item
    end

    local item_opts = {
        skip_gcd = true,
        skip_casting = true,
        skip_channeling = true,
        skip_moving = true,
    }

    if item then
        local ready = safe(function()
            return item:cooldown_up()
        end)
        if ready == false then
            return false
        end

        local used = safe(function()
            return item:use_self_safe("Pendant of the Violet Eye", item_opts)
        end)
        if used == true then
            return true
        end
    end

    local queued = safe(function()
        spell_queue:queue_item_self(item_id, spells.QUEUE_PRIORITY, "Pendant of the Violet Eye")
        return true
    end)
    if queued == true then
        return true
    end

    if player then
        local used_raw = safe(function()
            return core.input.use_item(item_id)
        end)
        if used_raw == true then
            return true
        end
    end

    return false
end

---High-value magic fallback IDs if is_purgable() scan table is empty.
spells.PURGE_BUFF_IDS = {
    17, 592, 600, 3747, 6065, 6066, 10898, 10899, 10900, 10901, 25217, 25218,
    1463, 8494, 8495, 10191, 10192, 10193, 27619, 28609, 27131,
    11426, 13031, 13032, 13033, 27134,
    7812, 19438, 19440, 19441, 19442, 19443, 27273,
    974, 32593, 32594,
    1022, 5599, 10278, 1044, 6940,
    139, 6074, 6075, 6076, 6077, 6078, 10927, 10928, 10929, 25315, 25221, 25222,
    774, 1058, 1430, 2090, 2091, 3627, 8910, 9839, 9840, 9841, 25299, 26981, 26982,
    8936, 8938, 8939, 8940, 8941, 9750, 9856, 9857, 9858, 26980,
    33763,
    10060, 12043, 12042, 11129, 12472, 16188, 17116, 29166, 2825, 32182,
}

---Scans purgeable buffs on target and returns highest priority number, or 0 if not purgeable.
---@param unit game_object
---@return number
function spells.unit_purge_priority(unit)
    if not unit then
        return 0
    end

    local scan = safe(function()
        return unit:is_purgable(250)
    end)
    if type(scan) == "table" and scan.is_purgeable == true then
        if type(scan.table) == "table" and #scan.table > 0 then
            local max_pri = 1
            for i = 1, #scan.table do
                local pri = scan.table[i] and scan.table[i].priority
                if type(pri) == "number" and pri > max_pri then
                    max_pri = pri
                end
            end
            return max_pri
        end
        return 1
    end

    local has_known = safe(function()
        return unit:buff_up(spells.PURGE_BUFF_IDS)
    end)
    if has_known == true then
        return 1
    end

    return 0
end

---True when the enemy has a dangerous magic shield, HoT, or caster cooldown.
---@param unit game_object
---@return boolean
function spells.unit_has_high_value_magic(unit)
    return spells.unit_purge_priority(unit) > 0
end

---Forecasted time to death in seconds (999 fallback).
---@param unit game_object
---@return number
function spells.unit_time_to_die(unit)
    if not unit then
        return 999
    end
    local ttd = safe(function()
        return unit:time_to_die()
    end)
    if type(ttd) == "number" and ttd >= 0 then
        return ttd
    end
    return 999
end

function spells.is_trivial_purge_unit(unit)
    if not unit then
        return true
    end

    local raw = safe(function()
        return unit:get_creature_type()
    end)
    local types = enums.creature_type
    if type(types) == "table" then
        if raw == types.CRITTER or raw == types.TOTEM or raw == types.NON_COMBAT_PET then
            return true
        end
    end
    if type(raw) == "string" then
        local lowered = string.lower(raw)
        if lowered == "critter" or lowered == "totem" or lowered == "non combat pet" then
            return true
        end
    end
    return false
end

function spells.is_humanoid_or_undead(unit)
    if not unit then
        return false
    end

    local raw = safe(function()
        return unit:get_creature_type()
    end)
    local types = enums.creature_type
    if type(types) == "table" then
        if raw == types.HUMANOID or raw == types.UNDEAD then
            return true
        end
    end
    if type(raw) == "string" then
        local lowered = string.lower(raw)
        return lowered == "humanoid" or lowered == "undead"
    end
    return raw == 6 or raw == 7
end

---Cancel the current hard-cast so an instant can fire immediately.
---@return boolean
function spells.stop_casting()
    return safe(function()
        core.input.cancel_spells()
        return true
    end) == true
end

---Rank 1 Earth Shock (8042). Cancels the current hard-cast first so the kick is instant.
---@param target game_object
---@return boolean
function spells.cast_earth_shock_interrupt(target)
    if not spells.earth_shock_r1 or not target then
        return false
    end

    spells.stop_casting()

    return spells.cast_unit(spells.earth_shock_r1, target, "Earth Shock (interrupt)", {
        skip_casting = true,
        skip_channeling = true,
        skip_moving = true,
    })
end

---Purge (8012). Cancels the current hard-cast first so Purge is instant.
---@param target game_object
---@return boolean
function spells.cast_purge(target)
    if not spells.purge or not target then
        return false
    end

    spells.stop_casting()

    return spells.cast_unit(spells.purge, target, "Purge", {
        skip_casting = true,
        skip_channeling = true,
        skip_moving = true,
    })
end

return spells
