-- ============================================================================
-- Elemental_Shammy - LOWEST HP TARGETING
-- ============================================================================
-- Author: BLIZZ
-- Version: 2.8
-- Folder: Elemental_Shammy_v2.8
-- Scan 100 yards. Attack the lowest-HP enemy inside Lightning Bolt range.
-- During a boss fight, prefer adds. Do not sticky-lock the boss while adds live.
-- Skip enemies with Spell Reflection / magic immunity (Buff Manager).
-- Require LoS. Unknown distance is out of range. Ties stay sticky, then closer.
-- ============================================================================

---@type izi_api
local izi = require("common/izi_sdk")

---@type unit_helper
local unit_helper = require("common/utility/unit_helper")

---@type buff_manager
local buff_manager = require("common/modules/buff_manager")

---@type enums
local enums = require("common/enums")

local targeting = {}

targeting.SCAN_RANGE = 100.0
targeting.CAST_RANGE = 36.0
targeting.LIGHTNING_BOLT_ID = 25449

-- Spell Reflect and similar auras expire quickly; keep the cache tight.
local AVOID_CACHE_MS = 50

local sticky_guid = nil

local AVOID_BUFF_NAMES = {
    "SPELL_REFLECTION",
    "ICE_BLOCK",
    "DIVINE_SHIELD",
    "CLOAK_OF_SHADOWS",
    "DISPERSION",
}

-- TBC Spell Reflection when buff_db is missing this key.
local SPELL_REFLECT_FALLBACK_IDS = { 23920 }

local AVOID_NAME_FRAGMENTS = {
    "spell reflection",
    "spell reflect",
    "mass spell reflection",
    "magic reflection",
    "reflect spells",
    "spell immunity",
    "ice block",
    "divine shield",
    "cloak of shadows",
    "dispersion",
}

local function collect_avoid_keys()
    local keys = {}
    local db = enums.buff_db
    if type(db) == "table" then
        for i = 1, #AVOID_BUFF_NAMES do
            local key = db[AVOID_BUFF_NAMES[i]]
            if key ~= nil then
                keys[#keys + 1] = key
            end
        end
    end
    keys[#keys + 1] = SPELL_REFLECT_FALLBACK_IDS
    return keys
end

local AVOID_KEYS = collect_avoid_keys()

local function safe(fn)
    local ok, result = pcall(fn)
    if ok then
        return result
    end
    return nil
end

local function unit_alive(unit)
    if not unit then
        return false
    end
    if safe(function() return unit:is_valid() end) ~= true then
        return false
    end
    if safe(function() return unit:is_alive() end) == false then
        return false
    end
    if safe(function() return unit:is_dead() end) == true then
        if safe(function() return unit:is_feign_death() end) ~= true then
            return false
        end
    end
    local dead_or_ghost = safe(function() return unit:is_dead_or_ghost() end)
    if dead_or_ghost == true then
        return false
    end
    return true
end

local function guid_of(unit)
    if not unit then
        return nil
    end
    local guid = safe(function() return unit:get_guid() end)
    if guid == nil then
        guid = safe(function() return unit:guid() end)
    end
    if guid == nil then
        return nil
    end
    return tostring(guid)
end

local function range_to(player, unit)
    local distance = safe(function() return unit:distance() end)
    if type(distance) == "number" and distance >= 0 and distance < 10000 then
        return distance
    end

    local from_other = safe(function() return unit:distance_to(player) end)
    if type(from_other) == "number" and from_other >= 0 and from_other < 10000 then
        return from_other
    end

    local player_pos = safe(function() return player:get_position() end)
    local unit_pos = safe(function() return unit:get_position() end)
    if player_pos and unit_pos then
        local by_pos = safe(function() return player_pos:dist_to(unit_pos) end)
        if type(by_pos) == "number" and by_pos >= 0 then
            return by_pos
        end
    end

    return nil
end

local function has_los(player, unit)
    if not player or not unit then
        return false
    end
    local los = safe(function() return player:los_to(unit) end)
    if los == false then
        return false
    end
    return true
end

local function in_range(player, unit, range)
    local flagged = safe(function() return unit:is_in_range(range) end)
    if flagged == true then
        return true
    end

    local distance = range_to(player, unit)
    if distance == nil then
        return false
    end
    return distance <= range
end

local function in_cast_range(player, unit)
    if unit == nil then
        return false
    end
    if not has_los(player, unit) then
        return false
    end

    local spell_range = safe(function()
        return unit:is_spell_in_range(targeting.LIGHTNING_BOLT_ID)
    end)
    if spell_range == true then
        return true
    end
    if spell_range == false then
        return false
    end

    return in_range(player, unit, targeting.CAST_RANGE)
end

local function is_attackable(player, unit)
    if not unit_alive(unit) then
        return false
    end
    if safe(function() return unit:is_feign_death() end) == true then
        return false
    end
    if safe(function() return player:can_attack(unit) end) == true then
        return true
    end
    if safe(function() return unit:is_valid_enemy() end) == true then
        return true
    end
    if safe(function() return unit_helper:is_valid_enemy(unit) end) == true then
        return true
    end
    if safe(function() return unit:is_dummy() end) == true then
        return true
    end
    if safe(function() return unit_helper:is_dummy(unit) end) == true then
        return true
    end
    return false
end

local function already_listed(list, unit)
    local guid = guid_of(unit)
    if not guid then
        return false
    end
    for i = 1, #list do
        if guid_of(list[i]) == guid then
            return true
        end
    end
    return false
end

local function collect_enemies(player, range)
    local list = safe(function()
        return izi.enemies_if(range, function(enemy)
            return is_attackable(player, enemy)
        end)
    end)
    if type(list) ~= "table" then
        list = safe(function()
            return izi.enemies(range, false)
        end)
    end
    if type(list) ~= "table" then
        list = {}
    end

    local out = {}
    for i = 1, #list do
        local enemy = list[i]
        if is_attackable(player, enemy) and in_range(player, enemy, range) then
            out[#out + 1] = enemy
        end
    end
    return out
end

local function current_game_target(player)
    local target = safe(function() return izi.target() end)
    if not is_attackable(player, target) then
        target = safe(function() return player:get_target() end)
    end
    if is_attackable(player, target) then
        return target
    end
    return nil
end

local function merge_unit(list, unit)
    if unit and not already_listed(list, unit) then
        list[#list + 1] = unit
    end
end

local function filter_cast_range(player, enemies)
    local out = {}
    for i = 1, #enemies do
        if in_cast_range(player, enemies[i]) then
            out[#out + 1] = enemies[i]
        end
    end
    return out
end

local function filter_cast_safe(player, enemies)
    local out = {}
    for i = 1, #enemies do
        local enemy = enemies[i]
        if in_cast_range(player, enemy) and not targeting.should_avoid(enemy) then
            out[#out + 1] = enemy
        end
    end
    return out
end

local function is_training_dummy(unit)
    if not unit then
        return false
    end
    if safe(function() return unit:is_dummy() end) == true then
        return true
    end
    return safe(function() return unit_helper:is_dummy(unit) end) == true
end

local function is_boss(unit)
    if not unit then
        return false
    end
    if is_training_dummy(unit) then
        return false
    end
    return safe(function() return unit_helper:is_boss(unit) end) == true
end

local function filter_non_boss(enemies)
    local out = {}
    for i = 1, #enemies do
        if not is_boss(enemies[i]) then
            out[#out + 1] = enemies[i]
        end
    end
    return out
end

local function drop_boss_sticky(enemies)
    if not sticky_guid then
        return
    end
    for i = 1, #enemies do
        local enemy = enemies[i]
        if guid_of(enemy) == sticky_guid and is_boss(enemy) then
            sticky_guid = nil
            return
        end
    end
end

local function aura_is_active(unit, key)
    if not unit or key == nil then
        return false
    end
    local data = safe(function()
        return buff_manager:get_aura_data(unit, key, AVOID_CACHE_MS)
    end)
    return type(data) == "table" and data.is_active == true
end

local function aura_name_is_avoid(name)
    if type(name) ~= "string" or name == "" then
        return false
    end
    local lower = string.lower(name)
    for i = 1, #AVOID_NAME_FRAGMENTS do
        if string.find(lower, AVOID_NAME_FRAGMENTS[i], 1, true) then
            return true
        end
    end
    return false
end

local function cache_has_avoid_aura(unit)
    local list = safe(function()
        return buff_manager:get_aura_cache(unit, AVOID_CACHE_MS)
    end)
    if type(list) ~= "table" then
        return false
    end
    for i = 1, #list do
        local entry = list[i]
        if type(entry) == "table" then
            if entry.is_active == false then
                -- skip expired cache leftovers
            elseif aura_name_is_avoid(entry.buff_name) then
                return true
            end
        end
    end
    return false
end

local function unit_is_magic_immune(unit)
    local flags = safe(function() return unit.DMG end)
    if type(flags) == "table" and flags.MAGICAL ~= nil then
        local immune = safe(function()
            return unit:is_damage_immune(flags.MAGICAL)
        end)
        if immune == true then
            return true
        end
    end
    return false
end

---True when caster spells should not go on this enemy (reflect / immune).
---@param unit game_object
---@return boolean
function targeting.should_avoid(unit)
    if not unit then
        return false
    end
    if not unit_alive(unit) then
        return false
    end

    for i = 1, #AVOID_KEYS do
        if aura_is_active(unit, AVOID_KEYS[i]) then
            return true
        end
    end

    if cache_has_avoid_aura(unit) then
        return true
    end

    if unit_is_magic_immune(unit) then
        return true
    end

    return false
end

---Current health as 0.0–1.0. Prefers unit_helper, then IZI %, then raw HP.
---@param unit game_object
---@return number
local function unit_health_pct(unit)
    local helper = safe(function()
        return unit_helper:get_health_percentage(unit)
    end)
    if type(helper) == "number" and helper >= 0 then
        if helper <= 1 then
            return helper
        end
        if helper <= 100 then
            return helper / 100
        end
    end

    local izi_pct = safe(function()
        return unit:get_health_percentage()
    end)
    if type(izi_pct) == "number" and izi_pct >= 0 then
        if izi_pct <= 1 then
            return izi_pct
        end
        if izi_pct <= 100 then
            return izi_pct / 100
        end
    end

    local hp = safe(function() return unit:get_health() end)
    local max_hp = safe(function() return unit:get_max_health() end)
    if type(hp) == "number" and type(max_hp) == "number" and max_hp > 0 then
        local ratio = hp / max_hp
        if ratio < 0 then
            return 0
        end
        if ratio > 1 then
            return 1
        end
        return ratio
    end

    return 1
end

local function squared_range_to(player_pos, unit)
    if not player_pos or not unit then
        return nil
    end
    local unit_pos = safe(function() return unit:get_position() end)
    if not unit_pos then
        return nil
    end
    local dist = safe(function()
        return unit_pos:squared_dist_to_ignore_z(player_pos)
    end)
    if type(dist) == "number" and dist >= 0 then
        return dist
    end
    return nil
end

---Lowest health percent in the list. Equal HP keeps sticky, then closer.
---@param player game_object
---@param enemies game_object[]
---@return game_object|nil
local function pick_lowest_hp(player, enemies)
    local best = nil
    local best_hp = nil
    local best_distance = nil
    local best_is_sticky = false

    local player_pos = safe(function() return player:get_position() end)

    for i = 1, #enemies do
        local enemy = enemies[i]
        local hp = unit_health_pct(enemy)
        local distance = squared_range_to(player_pos, enemy)
        if type(distance) ~= "number" then
            distance = 0
        end
        local is_sticky = guid_of(enemy) == sticky_guid

        local take = false
        if not best then
            take = true
        elseif hp < best_hp then
            take = true
        elseif hp == best_hp then
            if is_sticky and not best_is_sticky then
                take = true
            elseif is_sticky == best_is_sticky and distance < best_distance then
                take = true
            end
        end

        if take then
            best = enemy
            best_hp = hp
            best_distance = distance
            best_is_sticky = is_sticky
        end
    end

    return best
end

local function any_boss(enemies)
    for i = 1, #enemies do
        if is_boss(enemies[i]) then
            return true
        end
    end
    return false
end

---Refresh focus. Lowest-HP add wins in a boss fight; boss is last resort.
---@param player game_object
---@return table
function targeting.update(player)
    local scanned = collect_enemies(player, targeting.SCAN_RANGE)
    local current = current_game_target(player)
    if current and in_range(player, current, targeting.SCAN_RANGE) then
        merge_unit(scanned, current)
    end

    local castable = filter_cast_range(player, scanned)
    local safe_castable = filter_cast_safe(player, scanned)
    local fight_has_boss = any_boss(scanned)
    local pick_pool = safe_castable

    if fight_has_boss then
        local adds = filter_non_boss(safe_castable)
        if #adds > 0 then
            pick_pool = adds
            drop_boss_sticky(safe_castable)
        end
    end

    local focus = pick_lowest_hp(player, pick_pool)
    if not focus then
        focus = pick_lowest_hp(player, safe_castable)
    end

    if not focus and current and in_cast_range(player, current) and not targeting.should_avoid(current) then
        if not (fight_has_boss and is_boss(current) and #filter_non_boss(safe_castable) > 0) then
            focus = current
        end
    end

    sticky_guid = guid_of(focus)

    if focus then
        pcall(function()
            core.input.set_target(focus)
        end)
    end

    local can_rotate = focus ~= nil and in_cast_range(player, focus)

    return {
        target = can_rotate and focus or nil,
        focus = focus,
        in_cast_range = can_rotate,
        enemies = scanned,
        cast_enemies = safe_castable,
        count = #safe_castable,
        scan_count = #scanned,
        has_boss = any_boss(safe_castable),
        health_pct = focus and unit_health_pct(focus) or nil,
        avoided = focus == nil and #castable > 0,
    }
end

function targeting.in_range(player, unit, range)
    return in_range(player, unit, range)
end

function targeting.has_los(player, unit)
    return has_los(player, unit)
end

function targeting.clear()
    sticky_guid = nil
end

return targeting
