-- ============================================================================
-- Elemental_Shammy - GUI
-- ============================================================================
-- Purpose: Project-specific menu built on the reusable Sylvanas UI framework.
-- Assets (copy into <loader>/scripts_data/Elemental_Shammy/):
--   logo.png
--   ManlineSlabs-pgPVy.otf
-- Source copies live in this plugin's assets/ folder.
-- Author: BLIZZ
-- Version: 2.8
-- Folder: Elemental_Shammy_v2.8
-- ============================================================================

---@type color
local color = require("common/color")

---@type vec2
local vec2 = require("common/geometry/vector_2")

---@type enums
local enums = require("common/enums")

---@type izi_api
local izi = require("common/izi_sdk")

local ui = require("ui")

local gui = {}

local COL_WATER = color.new(80, 180, 255, 255)
local COL_LIGHTNING = color.new(255, 220, 80, 255)
local FONT_SMALL = enums.window_enums.font_id.FONT_SMALL

local menu = ui.new({
    id = "Elemental_Shammy_main",
    name = "Elemental Shammy",
    version = "2.8",
    header_text = "Elemental Shaman PVE",
    logo = "Elemental_Shammy\\logo.png",
    logo_width = 345,
    logo_height = 79,
    font = "Elemental_Shammy\\ManlineSlabs-pgPVy.otf",
    footer = "Contact Us On Discord: 1stblizz",
    header_hints = {
        { key = "Numpad 1", command = "Enable Rotation" },
        { key = "Numpad 2", command = "Chain Lightning" },
    },
    size = { w = 851, h = 644 },
    position = { x = 80, y = 180 },
    nav = "top",
    tabs = {
        { id = "general", label = "General" },
        { id = "combat",  label = "Combat" },
        { id = "healing", label = "Healing" },
        { id = "settings", label = "Settings" },
    },
})

menu:checkbox("nesr_enable", false, {
    label = "Enable Rotation",
    tab = "general",
    tooltip = "Master switch. Numpad 1 also toggles this.",
})
menu:checkbox("nesr_afk", false, {
    label = "Anti-AFK",
    tab = "general",
    tooltip = "Clears the AFK flag while enabled.",
})
menu:checkbox("nesr_movement", false, {
    label = "Movement",
    tab = "general",
    tooltip = "Follow out of combat and hold range in combat.",
})

menu:checkbox("nesr_chain", true, {
    label = "Chain Lightning",
    tab = "combat",
    tooltip = "Numpad 2 also toggles this.",
})
menu:checkbox("nesr_flame_shock", true, {
    label = "Flame Shock",
    tab = "combat",
})
menu:checkbox("nesr_earth_shock", false, {
    label = "Earth Shock",
    tab = "combat",
    tooltip = "Used as a moving filler. Rank 1 still interrupts when Interrupt is on.",
})
menu:checkbox("nesr_frost_shock", false, {
    label = "Frost Shock",
    tab = "combat",
})
menu:checkbox("nesr_drums", false, {
    label = "Drums of Battle",
    tab = "combat",
})
menu:checkbox("nesr_trinket_ve", false, {
    label = "Trinkets",
    tab = "combat",
    tooltip = "Icon of the Silver Crescent when equipped.",
})
menu:checkbox("nesr_interrupt", false, {
    label = "Interrupt",
    tab = "combat",
    tooltip = "Rank 1 Earth Shock kicks.",
})
menu:checkbox("nesr_purge", false, {
    label = "Purge",
    tab = "combat",
})

menu:checkbox("nesr_heal", false, {
    label = "Healing",
    tab = "healing",
    tooltip = "Healing Wave / Lesser Healing Wave / Chain Heal.",
})
menu:checkbox("nesr_water", false, {
    label = "Water Shield",
    tab = "healing",
    tooltip = "On = Water Shield. Off = Lightning Shield.",
})
menu:checkbox("nesr_show_gui", true, {
    label = "Show GUI",
})

local aliases = {
    enable      = "nesr_enable",
    drums       = "nesr_drums",
    heal        = "nesr_heal",
    afk         = "nesr_afk",
    purge       = "nesr_purge",
    interrupt   = "nesr_interrupt",
    trinket_ve  = "nesr_trinket_ve",
    chain       = "nesr_chain",
    frost_shock = "nesr_frost_shock",
    earth_shock = "nesr_earth_shock",
    flame_shock = "nesr_flame_shock",
    movement    = "nesr_movement",
    water       = "nesr_water",
    show_gui    = "nesr_show_gui",
}

local function checkbox_element(key)
    local id = aliases[key] or key
    return menu:element(id)
end

local function is_on(key)
    local element = checkbox_element(key)
    if not element then
        return false
    end
    local ok, state = pcall(function()
        return element:get_state()
    end)
    if ok and type(state) == "boolean" then
        return state
    end
    ok, state = pcall(function()
        return element:get()
    end)
    return ok and state == true
end

local function set_on(key, value)
    local element = checkbox_element(key)
    if not element then
        return
    end
    local on = value == true
    pcall(function()
        element:set(on)
    end)
end

gui.is_on = is_on
gui.set_on = set_on

menu.on_close = function()
    set_on("show_gui", false)
end

_G.Elemental_Shammy = _G.Elemental_Shammy or {}
local NS = _G.Elemental_Shammy
local MY_SESSION = NS.session

local last_toggle_at = {
    enable = -1,
    chain = -1,
}

local function toggle_id(id)
    if NS.session ~= MY_SESSION then
        return
    end
    local now = core.time()
    if type(now) ~= "number" then
        now = 0
    end
    if now - (last_toggle_at[id] or -1) < 0.20 then
        return
    end
    last_toggle_at[id] = now
    set_on(id, not is_on(id))
end

if type(NS.unbind_hotkeys) == "function" then
    pcall(NS.unbind_hotkeys)
    NS.unbind_hotkeys = nil
end

local unsubs = {}

local function watch_key(code, id)
    local ok, unsub = pcall(function()
        return izi.on_key_release(code, function()
            toggle_id(id)
        end)
    end)
    if ok and type(unsub) == "function" then
        unsubs[#unsubs + 1] = unsub
    end
end

-- Sylvanas numpad codes (native keybind constructor values). IZI tracks these;
-- core.input.is_key_pressed does not — it only accepts Windows VK codes.
watch_key(997, "enable") -- Numpad 1
watch_key(998, "chain")  -- Numpad 2
watch_key(0x61, "enable") -- VK_NUMPAD1
watch_key(0x62, "chain")  -- VK_NUMPAD2
watch_key(0x23, "enable") -- VK_END (NumLock off Numpad 1)
watch_key(0x28, "chain")  -- VK_DOWN (NumLock off Numpad 2)

NS.unbind_hotkeys = function()
    for i = 1, #unsubs do
        pcall(unsubs[i])
    end
end

-- Windows VK only. Do not poll 997/998 here; out-of-range codes can stick "down".
local KEY_CODES = {
    enable = { 0x61, 0x23 },
    chain  = { 0x62, 0x28 },
}

local key_was_down = {
    enable = false,
    chain = false,
}

local function key_is_down(codes)
    for i = 1, #codes do
        local ok, pressed = pcall(function()
            return core.input.is_key_pressed(codes[i])
        end)
        if ok and pressed == true then
            return true
        end
    end
    return false
end

function gui.process_keybinds()
    local binds = { "enable", "chain" }
    for i = 1, #binds do
        local id = binds[i]
        local down = key_is_down(KEY_CODES[id])
        if down and not key_was_down[id] then
            toggle_id(id)
        end
        key_was_down[id] = down
    end
end

function gui.is_water()
    return is_on("water")
end

function gui.is_lightning()
    return not is_on("water")
end

local function rotation_last_action()
    local ok, rotation = pcall(require, "rotation")
    if not ok or type(rotation) ~= "table" then
        return "—"
    end
    if type(rotation.last_action) ~= "function" then
        return "—"
    end
    local text = rotation.last_action()
    if type(text) ~= "string" or text == "" then
        return "—"
    end
    return text
end

local function state_color()
    if is_on("enable") then
        return color.new(90, 210, 110, 255)
    end
    return color.new(210, 78, 78, 255)
end

menu:set_status({
    {
        label = "State",
        value = function()
            return is_on("enable") and "Running" or "Idle"
        end,
        color = state_color,
    },
    {
        label = "Shield",
        value = function()
            return is_on("water") and "Water" or "Lightning"
        end,
        color = function()
            return is_on("water") and COL_WATER or COL_LIGHTNING
        end,
    },
    {
        label = "Movement",
        value = function()
            return is_on("movement") and "On" or "Off"
        end,
    },
    {
        label = "Last Action",
        value = rotation_last_action,
    },
})

menu:set_actions({
    {
        id = "toggle_enable",
        label = "Start",
        style = "start",
        on_click = function()
            set_on("enable", true)
        end,
    },
    {
        id = "toggle_pause",
        label = "Pause",
        style = "pause",
        on_click = function()
            set_on("enable", false)
        end,
    },
    {
        id = "toggle_stop",
        label = "Stop",
        style = "stop",
        on_click = function()
            set_on("enable", false)
            set_on("movement", false)
        end,
    },
})

menu:on_tab("healing", function(win, x, y, w, h)
    local water = is_on("water")
    local line = water and "Active Shield:  WATER" or "Active Shield:  LIGHTNING"
    local text_color = water and COL_WATER or COL_LIGHTNING
    local row_h = 35
    local gap = 7
    local row_y = y + 4 + (row_h + gap) * 2 + 10
    local row_hh = 32
    local v1 = vec2.new(x, row_y)
    local v2 = vec2.new(x + w, row_y + row_hh)
    local fill = color.new(16, 18, 26, 200)
    if win:is_mouse_hovering_rect(v1, v2) then
        fill = color.new(22, 26, 36, 230)
    end
    win:render_rect_filled(v1, v2, fill, 3.0)
    win:render_rect(v1, v2, text_color, 3.0, 1.0)
    local sz = win:get_text_size(line)
    local ty = row_y + math.floor((row_hh - sz.y) * 0.5)
    win:render_text(FONT_SMALL, vec2.new(x + 10, ty), text_color, line)
    if win:is_rect_clicked(v1, v2) then
        set_on("water", not water)
    end
end)

local function draw_bind_info_row(win, x, y, w, key_text, command, on, id)
    local row_h = 35
    local v1 = vec2.new(x, y)
    local v2 = vec2.new(x + w, y + row_h)
    local fill = color.new(16, 18, 26, 200)
    local border = color.new(132, 102, 42, 190)
    if on then
        fill = color.new(24, 52, 92, 255)
        border = color.new(64, 176, 220, 255)
    end
    if win:is_mouse_hovering_rect(v1, v2) then
        fill = color.new(22, 26, 36, 230)
    end
    win:render_rect_filled(v1, v2, fill, 3.0)
    win:render_rect(v1, v2, border, 3.0, 1.0)
    local status = on and "ON" or "OFF"
    local status_col = on and color.new(90, 210, 110, 255) or color.new(210, 78, 78, 255)
    local key_sz = win:get_text_size(key_text)
    local status_sz = win:get_text_size(status)
    local ty = y + math.floor((row_h - key_sz.y) * 0.5)
    win:render_text(FONT_SMALL, vec2.new(x + 12, ty), color.new(248, 226, 132, 255), key_text)
    win:render_text(FONT_SMALL, vec2.new(x + 12 + key_sz.x + 16, ty), color.new(232, 222, 196, 255), command)
    win:render_text(FONT_SMALL, vec2.new(x + w - status_sz.x - 12, ty), status_col, status)
    if win:is_rect_clicked(v1, v2) then
        toggle_id(id)
    end
    return y + row_h + 7
end

menu:on_tab("settings", function(win, x, y, w, h)
    local row_y = y + 8
    row_y = draw_bind_info_row(win, x, row_y, w, "Numpad 1", "Enable Rotation", is_on("enable"), "enable")
    draw_bind_info_row(win, x, row_y, w, "Numpad 2", "Chain Lightning", is_on("chain"), "chain")
end)

local gui_opened = false

function gui.draw()
    local show = is_on("show_gui")
    if not show then
        gui_opened = false
        menu:set_visible(false)
        return
    end

    if not gui_opened then
        menu:set_visible(true)
        gui_opened = true
    end

    local start_btn = menu.actions[1]
    local pause_btn = menu.actions[2]
    if start_btn then
        start_btn.label = is_on("enable") and "Running" or "Start"
        start_btn.style = is_on("enable") and "neutral" or "start"
    end
    if pause_btn then
        pause_btn.label = is_on("enable") and "Pause" or "Paused"
    end
    menu:draw()
    if menu:is_closed() then
        set_on("show_gui", false)
        gui_opened = false
    end
end

return gui
