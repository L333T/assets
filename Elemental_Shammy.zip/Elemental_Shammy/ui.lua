-- ============================================================================
-- Reusable Sylvanas Menu UI
-- ============================================================================
-- Configuration-driven window framework for Project Sylvanas plugins.
-- Uses only verified core.menu.window / core.menu.* / assets_helper APIs.
-- Consuming projects supply name, logo, tabs, controls, and theme overrides.
-- Author: BLIZZ
-- Version: 2.8
-- Folder: Elemental_Shammy_v2.8
-- ============================================================================

---@type color
local color = require("common/color")

---@type vec2
local vec2 = require("common/geometry/vector_2")

---@type enums
local enums = require("common/enums")

---@type assets_helper
local assets = require("common/utility/assets_helper")

local ui = {}

local WE = enums.window_enums
local FONT_SMALL = WE.font_id.FONT_SMALL
local FONT_NORMAL = WE.font_id.FONT_NORMAL
local FONT_BIG = WE.font_id.FONT_BIG

-- ---------------------------------------------------------------------------
-- Theme
-- ---------------------------------------------------------------------------

local function col(r, g, b, a)
    return color.new(r, g, b, a or 255)
end

function ui.default_theme()
    return {
        bg_window        = col(10, 12, 18, 245),
        bg_header        = col(8, 10, 16, 255),
        bg_panel         = col(14, 16, 24, 230),
        bg_panel_alt     = col(18, 20, 28, 230),
        bg_nav           = col(12, 14, 22, 240),
        bg_tab           = col(20, 24, 34, 230),
        bg_tab_hover     = col(28, 34, 48, 255),
        bg_tab_active    = col(24, 52, 92, 255),
        bg_input         = col(16, 18, 26, 255),
        bg_row           = col(16, 18, 26, 180),
        bg_row_hover     = col(22, 26, 36, 220),

        border_window    = col(176, 138, 58, 230),
        border_panel     = col(132, 102, 42, 190),
        border_header    = col(204, 164, 72, 240),
        border_tab       = col(70, 90, 130, 200),

        text_primary     = col(232, 222, 196, 255),
        text_secondary   = col(168, 158, 128, 230),
        text_header      = col(248, 226, 132, 255),
        text_dim         = col(118, 112, 96, 200),
        text_on          = col(90, 210, 110, 255),
        text_off         = col(210, 78, 78, 255),

        accent           = col(64, 176, 220, 255),
        accent_active    = col(90, 198, 236, 255),
        accent_hover     = col(110, 188, 230, 255),

        button_start     = col(32, 118, 48, 255),
        button_start_hi  = col(48, 150, 64, 255),
        button_pause     = col(176, 138, 28, 255),
        button_pause_hi  = col(210, 168, 42, 255),
        button_stop      = col(156, 36, 36, 255),
        button_stop_hi   = col(190, 50, 50, 255),
        button_neutral   = col(42, 46, 58, 255),
        button_neutral_hi = col(58, 64, 80, 255),

        success          = col(80, 200, 90, 255),
        warning          = col(220, 176, 56, 255),
        danger           = col(210, 70, 70, 255),

        font             = FONT_NORMAL,
        font_small       = FONT_SMALL,
        font_big         = FONT_BIG,
        font_title       = WE.font_id.FONT_SEMI_BIG or FONT_BIG,
        font_section     = FONT_NORMAL,

        header_font_size = 18,
        section_font_size = 18,
        normal_font_size = 16,
        small_font_size  = 15,

        left_margin      = 21,
        top_margin       = 14,
        header_height    = 136,
        footer_height    = 39,
        nav_height       = 39,
        nav_width        = 147,
        panel_gap        = 16,
        control_gap      = 7,
        section_gap      = 14,
        control_width    = 368,
        row_height       = 35,
        button_height    = 39,
        border_thickness = 1.0,
        rounding         = 5.0,
    }
end

local function copy_theme(src)
    local out = {}
    for k, v in pairs(src) do
        out[k] = v
    end
    return out
end

local function apply_theme_overrides(base, overrides)
    if type(overrides) ~= "table" then
        return base
    end
    for k, v in pairs(overrides) do
        base[k] = v
    end
    return base
end

-- ---------------------------------------------------------------------------
-- Helpers
-- ---------------------------------------------------------------------------

local function safe(fn)
    local ok, result = pcall(fn)
    if ok then
        return result
    end
    return nil
end

local function size_of(win, text)
    local sz = safe(function()
        return win:get_text_size(text)
    end)
    if sz and type(sz.x) == "number" then
        return sz
    end
    return vec2.new(#tostring(text or "") * 7, 16)
end

local function size_of_font(win, font, font_size, text)
    if type(font_size) == "number" and font_size > 0 then
        local sz = safe(function()
            return win:get_text_size_custom(font, font_size, text)
        end)
        if sz and type(sz.x) == "number" then
            return sz
        end
    end
    return size_of(win, text)
end

local function key_display_name(code)
    if type(code) ~= "number" or code <= 0 then
        return "Unbound"
    end
    if code >= 997 and code <= 1005 then
        return "Numpad " .. tostring(code - 996)
    end
    if code == 1006 then
        return "Numpad 0"
    end
    if code >= 96 and code <= 105 then
        if code == 96 then
            return "Numpad 0"
        end
        return "Numpad " .. tostring(code - 96)
    end
    return "Key " .. tostring(code)
end

local function draw_text(win, font, pos, colr, text, font_size)
    if type(text) ~= "string" or text == "" then
        return
    end
    if type(font_size) == "number" and font_size > 0 then
        local ok = pcall(function()
            win:render_text_custom_size(font, pos, colr, font_size, text)
        end)
        if ok then
            return
        end
    end
    win:render_text(font, pos, colr, text)
end

local function draw_rect(win, pmin, pmax, fill, border, rounding, thickness)
    local r = rounding or 4.0
    win:render_rect_filled(pmin, pmax, fill, r)
    if border then
        win:render_rect(pmin, pmax, border, r, thickness or 1.0)
    end
end

local function hovered(win, pmin, pmax)
    return win:is_mouse_hovering_rect(pmin, pmax) == true
end

local function clicked(win, pmin, pmax)
    if win:is_rect_clicked(pmin, pmax) then
        pcall(function()
            win:is_mouse_hovering_rect_block_movement(pmin, pmax)
        end)
        return true
    end
    return false
end

local function block_drag(win, pmin, pmax)
    pcall(function()
        win:is_mouse_hovering_rect_block_movement(pmin, pmax)
    end)
end

local function resolve_bool(elem)
    if not elem then
        return false
    end
    local state = safe(function()
        return elem:get_state()
    end)
    if type(state) == "boolean" then
        return state
    end
    state = safe(function()
        return elem:get()
    end)
    return state == true
end

local function resolve_number(elem, fallback)
    if not elem then
        return fallback
    end
    local value = safe(function()
        return elem:get()
    end)
    if type(value) == "number" then
        return value
    end
    return fallback
end

local function resolve_text(elem)
    if not elem then
        return ""
    end
    local text = safe(function()
        return elem:get_text()
    end)
    if type(text) == "string" then
        return text
    end
    text = safe(function()
        return elem:get()
    end)
    if type(text) == "string" then
        return text
    end
    return ""
end

local function set_bool(elem, value)
    if not elem then
        return
    end
    pcall(function()
        elem:set(value == true)
    end)
end

local function call_value(value)
    if type(value) == "function" then
        local result = safe(value)
        if result == nil then
            return ""
        end
        return tostring(result)
    end
    if value == nil then
        return ""
    end
    return tostring(value)
end

-- ---------------------------------------------------------------------------
-- Custom font (optional). Path is scripts_data-relative. Never a remote URL.
-- ---------------------------------------------------------------------------

local function load_custom_font(path, size)
    if type(path) ~= "string" or path == "" then
        return nil
    end
    if string.find(path, "://", 1, true) then
        return nil
    end
    local data = safe(function()
        return core.read_data_file(path)
    end)
    if type(data) ~= "string" or #data < 64 then
        data = safe(function()
            return assets:load_local_data(path, "")
        end)
    end
    if type(data) ~= "string" or #data < 64 then
        return nil
    end
    local font_id = safe(function()
        return core.graphics.load_font(data, size)
    end)
    if type(font_id) == "number" and font_id ~= 0 then
        return font_id
    end
    return nil
end

-- ---------------------------------------------------------------------------
-- Instance
-- ---------------------------------------------------------------------------

local Menu = {}
Menu.__index = Menu

function ui.new(config)
    config = config or {}
    local self = setmetatable({}, Menu)

    self.config = config
    self.id = config.id or "sylvanas_ui_window"
    self.name = config.name or "Project"
    self.version = config.version or "1.0"
    self.subtitle = config.subtitle or ""
    self.logo = config.logo or ""
    self.logo_width = config.logo_width or 280
    self.logo_height = config.logo_height or 64
    self.header_text = config.header_text or ""
    self.font_path = config.font or config.font_path or ""
    self.footer = config.footer or ""
    self.nav_style = config.nav or "top"

    local size_w, size_h = 828, 621
    if type(config.size) == "table" then
        size_w = config.size.w or config.size.x or size_w
        size_h = config.size.h or config.size.y or size_h
    end
    local pos_x, pos_y = 80, 180
    if type(config.position) == "table" then
        pos_x = config.position.x or pos_x
        pos_y = config.position.y or pos_y
    end

    self.width = size_w
    self.height = size_h

    self.theme = apply_theme_overrides(copy_theme(ui.default_theme()), config.theme)
    self.custom_font_loaded = false
    self._next_font_try = 0
    self._logo_tex = nil
    self._next_logo_try = 0
    self._logo_logged = false

    self.window = core.menu.window(self.id)
    self.window:set_initial_size(vec2.new(size_w, size_h))
    self.window:set_initial_position(vec2.new(pos_x, pos_y))
    self.window:set_visibility(true)
    pcall(function()
        self.window:set_corner_rounding(self.theme.rounding or 4.0)
    end)

    self.tab_store = core.menu.slider_int(1, 32, 1, self.id .. "_active_tab")
    self.elements = {}
    self.order = {}
    self.tabs = {}
    self.tab_draw = {}
    self.status_items = config.status or {}
    self.actions = config.actions or {}
    self.header_hints = config.header_hints or {}
    self.on_close = config.on_close
    self.visible = true
    self._closed = false
    self._tab_scroll = {}
    self._scroll_drag = nil

    if type(config.tabs) == "table" then
        for i = 1, #config.tabs do
            local tab = config.tabs[i]
            if type(tab) == "table" and tab.id then
                self.tabs[#self.tabs + 1] = {
                    id = tab.id,
                    label = tab.label or tab.id,
                }
            elseif type(tab) == "string" then
                self.tabs[#self.tabs + 1] = { id = tab, label = tab }
            end
        end
    end

    return self
end

function Menu:retry_font()
    if self.custom_font_loaded or self.font_path == "" then
        return
    end
    local now = core.time()
    if type(now) == "number" and now < (self._next_font_try or 0) then
        return
    end
    self._next_font_try = (type(now) == "number" and now or 0) + 2.0

    local title_size = self.theme.header_font_size or 18
    local section_size = self.theme.section_font_size or 14
    local loaded_title = load_custom_font(self.font_path, title_size)
    local loaded_section = load_custom_font(self.font_path, section_size)
    if loaded_title then
        self.theme.font_title = loaded_title
        self.custom_font_loaded = true
    end
    if loaded_section then
        self.theme.font_section = loaded_section
        self.custom_font_loaded = true
    end
end

function Menu:read_data_bytes(path)
    if type(path) ~= "string" or path == "" then
        return nil
    end
    local paths = { path }
    local alt = string.gsub(path, "\\", "/")
    if alt ~= path then
        paths[#paths + 1] = alt
    end
    local alt2 = string.gsub(path, "/", "\\")
    if alt2 ~= path and alt2 ~= alt then
        paths[#paths + 1] = alt2
    end
    for i = 1, #paths do
        local bytes = safe(function()
            return core.read_data_file(paths[i])
        end)
        if type(bytes) == "string" and #bytes > 64 then
            return bytes
        end
        bytes = safe(function()
            return assets:load_local_data(paths[i], "")
        end)
        if type(bytes) == "string" and #bytes > 64 then
            return bytes
        end
    end
    return nil
end

function Menu:ensure_logo()
    if self._logo_tex and self._logo_tex.id then
        return self._logo_tex
    end
    if self.logo == "" then
        return nil
    end
    local now = core.time()
    if type(now) == "number" and now < (self._next_logo_try or 0) then
        return nil
    end
    self._next_logo_try = (type(now) == "number" and now or 0) + 1.0

    local bytes = self:read_data_bytes(self.logo)
    if type(bytes) ~= "string" or #bytes < 64 then
        if not self._logo_logged then
            self._logo_logged = true
            core.log_warning("[UI] Logo not found in scripts_data: " .. tostring(self.logo))
        end
        return nil
    end

    local tex_id, w, h = nil, nil, nil
    local ok = pcall(function()
        tex_id, w, h = core.graphics.load_texture(bytes)
    end)
    if ok and type(tex_id) == "number" then
        self._logo_tex = {
            id = tex_id,
            w = (type(w) == "number" and w > 0) and w or 2146,
            h = (type(h) == "number" and h > 0) and h or 492,
        }
        if not self._logo_logged then
            self._logo_logged = true
            core.log("[UI] Logo loaded from scripts_data (" .. tostring(#bytes) .. " bytes)")
        end
        return self._logo_tex
    end
    return nil
end

local function store_element(self, kind, id, element, opts)
    opts = opts or {}
    local record = {
        kind = kind,
        id = id,
        element = element,
        label = opts.label or id,
        tooltip = opts.tooltip,
        tab = opts.tab,
        min = opts.min,
        max = opts.max,
        items = opts.items,
        width = opts.width,
        style = opts.style,
        on_click = opts.on_click,
        column = opts.column or 1,
    }
    self.elements[id] = record
    self.order[#self.order + 1] = record
    return element
end

function Menu:checkbox(id, default_value, opts)
    opts = opts or {}
    local element = core.menu.checkbox(default_value == true, id)
    return store_element(self, "checkbox", id, element, opts)
end

function Menu:slider_int(id, min_value, max_value, default_value, opts)
    opts = opts or {}
    opts.min = min_value
    opts.max = max_value
    local element = core.menu.slider_int(min_value, max_value, default_value, id)
    return store_element(self, "slider_int", id, element, opts)
end

function Menu:slider_float(id, min_value, max_value, default_value, opts)
    opts = opts or {}
    opts.min = min_value
    opts.max = max_value
    local element = core.menu.slider_float(min_value, max_value, default_value, id)
    return store_element(self, "slider_float", id, element, opts)
end

function Menu:text_input(id, save_input, opts)
    opts = opts or {}
    local element = core.menu.text_input(id, save_input ~= false)
    return store_element(self, "text_input", id, element, opts)
end

function Menu:combobox(id, default_index, items, opts)
    opts = opts or {}
    opts.items = items or {}
    local element = core.menu.combobox(default_index or 1, id)
    return store_element(self, "combobox", id, element, opts)
end

function Menu:keybind(id, default_key, initial_toggle, opts)
    opts = opts or {}
    local element = core.menu.keybind(default_key, initial_toggle == true, id)
    return store_element(self, "keybind", id, element, opts)
end

function Menu:button(id, opts)
    opts = opts or {}
    local element = core.menu.button(id)
    return store_element(self, "button", id, element, opts)
end

function Menu:element(id)
    local record = self.elements[id]
    return record and record.element or nil
end

function Menu:get(id)
    local record = self.elements[id]
    if not record or not record.element then
        return nil
    end
    if record.kind == "checkbox" or record.kind == "keybind" then
        return resolve_bool(record.element)
    end
    if record.kind == "text_input" then
        return resolve_text(record.element)
    end
    return resolve_number(record.element, nil)
end

function Menu:set(id, value)
    local record = self.elements[id]
    if not record or not record.element then
        return
    end
    if record.kind == "checkbox" then
        set_bool(record.element, value)
        return
    end
    pcall(function()
        record.element:set(value)
    end)
end

function Menu:on_tab(tab_id, fn)
    self.tab_draw[tab_id] = fn
end

function Menu:set_status(items)
    self.status_items = items or {}
end

function Menu:set_actions(items)
    self.actions = items or {}
end

function Menu:set_tabs(tabs)
    self.tabs = {}
    if type(tabs) ~= "table" then
        return
    end
    for i = 1, #tabs do
        local tab = tabs[i]
        if type(tab) == "table" and tab.id then
            self.tabs[#self.tabs + 1] = {
                id = tab.id,
                label = tab.label or tab.id,
            }
        end
    end
end

function Menu:active_tab()
    local index = resolve_number(self.tab_store, 1)
    if index < 1 then
        index = 1
    end
    if index > #self.tabs and #self.tabs > 0 then
        index = #self.tabs
    end
    local tab = self.tabs[index]
    return tab and tab.id or nil, index
end

function Menu:set_active_tab(tab_id)
    for i = 1, #self.tabs do
        if self.tabs[i].id == tab_id then
            pcall(function()
                self.tab_store:set(i)
            end)
            return
        end
    end
end

-- ---------------------------------------------------------------------------
-- Layout
-- ---------------------------------------------------------------------------

function Menu:layout_metrics(win)
    local t = self.theme
    local size = safe(function()
        return win:get_size()
    end)
    local w = (size and size.x) or self.width
    local h = (size and size.y) or self.height
    local left = t.left_margin
    local header_h = t.header_height
    local footer_h = t.footer_height
    local nav_h = t.nav_height
    local nav_w = t.nav_width
    local top_nav = self.nav_style ~= "left"
    local content_x = left
    local content_y = header_h + (top_nav and (nav_h + 10) or 10)
    if not top_nav then
        content_x = left + nav_w + t.panel_gap
    end
    local content_w = w - content_x - left
    local content_h = h - content_y - footer_h - 8
    return {
        w = w,
        h = h,
        left = left,
        header_h = header_h,
        footer_h = footer_h,
        nav_h = nav_h,
        nav_w = nav_w,
        top_nav = top_nav,
        content_x = content_x,
        content_y = content_y,
        content_w = content_w,
        content_h = content_h,
    }
end

-- ---------------------------------------------------------------------------
-- Chrome
-- ---------------------------------------------------------------------------

function Menu:draw_header(win, m)
    local t = self.theme
    local pmin = vec2.new(0, 0)
    local pmax = vec2.new(m.w, m.header_h)
    local painted = pcall(function()
        win:render_page_title(pmin, pmax, t.bg_header, t.border_header, t.accent, 0.0, 0.0, core.time(), 1.0)
    end)
    if not painted then
        draw_rect(win, pmin, pmax, t.bg_header, t.border_header, 0.0, t.border_thickness)
    end

    local pad = t.left_margin
    local bottom_pad = 10

    local title = self.header_text
    local sub = ""
    if type(title) ~= "string" or title == "" then
        title = self.name
        sub = self.subtitle
        if sub == "" and self.version ~= "" then
            sub = "v" .. tostring(self.version)
        elseif sub ~= "" and self.version ~= "" then
            sub = sub .. "  ·  v" .. tostring(self.version)
        end
    end

    local title_font = t.font_title or t.font
    local title_size = t.header_font_size
    local title_sz = size_of_font(win, title_font, title_size, title)
    local sub_sz = vec2.new(0, 0)
    if sub ~= "" then
        sub_sz = size_of_font(win, t.font_small, t.small_font_size, sub)
    end
    local text_h = title_sz.y
    if sub ~= "" then
        text_h = text_h + 4 + sub_sz.y
    end

    local logo = self:ensure_logo()
    local dw, dh = 0, 0
    if logo and logo.id then
        local native_w = logo.w
        local native_h = logo.h
        local max_h = m.header_h - bottom_pad - text_h - 4
        if max_h < 24 then
            max_h = 24
        end
        local max_w = math.min(self.logo_width, math.floor(m.w * 0.72))
        local scale = math.min(self.logo_width / native_w, self.logo_height / native_h, max_w / native_w, max_h / native_h)
        dw = math.max(1, math.floor(native_w * scale))
        dh = math.max(1, math.floor(native_h * scale))
    end

    local ly = 8
    if dw > 0 and logo and logo.id then
        local lx = math.floor((m.w - dw) * 0.5)
        local band_h = m.header_h - text_h - 4
        ly = math.floor((band_h - dh) * 0.62)
        if ly < 8 then
            ly = 8
        end
        if ly + dh > band_h then
            ly = math.max(4, band_h - dh)
        end
        local wpos = safe(function()
            return win:get_position()
        end)
        local sx = lx
        local sy = ly
        if wpos and type(wpos.x) == "number" then
            sx = wpos.x + lx
            sy = wpos.y + ly
        end
        pcall(function()
            core.graphics.draw_texture(logo.id, vec2.new(sx, sy), dw, dh, color.white(255), true)
        end)
    end

    local tx = pad
    local ty = math.floor((m.header_h - text_h) * 0.5)
    if dh > 0 then
        ty = ly + dh - 6
        local min_ty = ly + dh - 10
        if ty < min_ty then
            ty = min_ty
        end
        local max_ty = m.header_h - bottom_pad - text_h
        if ty > max_ty then
            ty = max_ty
        end
    end
    draw_text(win, title_font, vec2.new(tx, ty), t.text_header, title, title_size)
    if sub ~= "" then
        draw_text(win, t.font_small, vec2.new(tx, ty + title_sz.y + 4), t.text_secondary, sub, t.small_font_size)
    end

    local hints = self.header_hints
    if type(hints) == "function" then
        hints = safe(hints)
    end
    if type(hints) == "table" and #hints > 0 then
        local key_w = 0
        local line_h = 16
        for i = 1, #hints do
            local hint = hints[i]
            if type(hint) == "table" then
                local ksz = size_of_font(win, t.font_small, t.small_font_size, tostring(hint.key or ""))
                if ksz.x > key_w then
                    key_w = ksz.x
                end
                if ksz.y > line_h then
                    line_h = ksz.y
                end
            end
        end
        local col_gap = 14
        local block_h = (#hints * line_h) + ((#hints - 1) * 3)
        local hx = m.w - pad - 40
        local max_cmd_w = 0
        for i = 1, #hints do
            local hint = hints[i]
            if type(hint) == "table" then
                local csz = size_of_font(win, t.font_small, t.small_font_size, tostring(hint.command or ""))
                if csz.x > max_cmd_w then
                    max_cmd_w = csz.x
                end
            end
        end
        hx = m.w - 44 - key_w - col_gap - max_cmd_w
        if hx < (tx + title_sz.x + 24) then
            hx = tx + title_sz.x + 24
        end
        local hy = math.floor((m.header_h - block_h) * 0.5)
        if hy < 8 then
            hy = 8
        end
        for i = 1, #hints do
            local hint = hints[i]
            if type(hint) == "table" then
                local row_y = hy + ((i - 1) * (line_h + 3))
                draw_text(win, t.font_small, vec2.new(hx, row_y), t.text_header, tostring(hint.key or ""), t.small_font_size)
                draw_text(win, t.font_small, vec2.new(hx + key_w + col_gap, row_y), t.text_primary, tostring(hint.command or ""), t.small_font_size)
            end
        end
    end
end

function Menu:draw_nav(win, m)
    if #self.tabs == 0 then
        return
    end
    local t = self.theme
    local active_id, active_index = self:active_tab()

    if m.top_nav then
        local y = m.header_h + 6
        local x = t.left_margin
        local gap = 6
        local count = #self.tabs
        local avail = m.w - (t.left_margin * 2) - ((count - 1) * gap)
        local tab_w = math.floor(avail / math.max(count, 1))
        if tab_w < 64 then
            tab_w = 64
        end
        for i = 1, count do
            local tab = self.tabs[i]
            local pmin = vec2.new(x, y)
            local pmax = vec2.new(x + tab_w, y + t.nav_height)
            local is_active = tab.id == active_id
            local is_hover = hovered(win, pmin, pmax)
            local fill = t.bg_tab
            local border = t.border_tab
            local text_col = t.text_secondary
            if is_active then
                fill = t.bg_tab_active
                border = t.accent
                text_col = t.text_primary
            elseif is_hover then
                fill = t.bg_tab_hover
                text_col = t.text_primary
            end
            draw_rect(win, pmin, pmax, fill, border, t.rounding, 1.0)
            local sz = size_of_font(win, t.font, t.normal_font_size, tab.label)
            local tx = x + math.floor((tab_w - sz.x) * 0.5)
            local ty = y + math.floor((t.nav_height - sz.y) * 0.5)
            draw_text(win, t.font, vec2.new(tx, ty), text_col, tab.label, t.normal_font_size)
            block_drag(win, pmin, pmax)
            if clicked(win, pmin, pmax) then
                pcall(function()
                    self.tab_store:set(i)
                end)
                active_index = i
                active_id = tab.id
            end
            x = x + tab_w + gap
        end
        return
    end

    local y = m.header_h + 8
    local x = t.left_margin
    local tab_w = t.nav_width
    for i = 1, #self.tabs do
        local tab = self.tabs[i]
        local pmin = vec2.new(x, y)
        local pmax = vec2.new(x + tab_w, y + t.nav_height)
        local is_active = tab.id == active_id
        local is_hover = hovered(win, pmin, pmax)
        local fill = t.bg_tab
        local border = t.border_tab
        local text_col = t.text_secondary
        if is_active then
            fill = t.bg_tab_active
            border = t.accent
            text_col = t.text_primary
        elseif is_hover then
            fill = t.bg_tab_hover
            text_col = t.text_primary
        end
        draw_rect(win, pmin, pmax, fill, border, t.rounding, 1.0)
        local sz = size_of_font(win, t.font, t.normal_font_size, tab.label)
        local ty = y + math.floor((t.nav_height - sz.y) * 0.5)
        draw_text(win, t.font, vec2.new(x + 10, ty), text_col, tab.label, t.normal_font_size)
        block_drag(win, pmin, pmax)
        if clicked(win, pmin, pmax) then
            pcall(function()
                self.tab_store:set(i)
            end)
        end
        y = y + t.nav_height + 4
    end
end

function Menu:draw_panel(win, x, y, w, h, title)
    local t = self.theme
    local pmin = vec2.new(x, y)
    local pmax = vec2.new(x + w, y + h)
    draw_rect(win, pmin, pmax, t.bg_panel, t.border_panel, t.rounding, 1.0)

    if title and title ~= "" then
        local head_h = 28
        local head_max = vec2.new(x + w, y + head_h)
        pcall(function()
            win:render_section_header(
                pmin,
                head_max,
                t.bg_panel_alt,
                t.bg_panel,
                t.text_header,
                1.0,
                t.rounding,
                0.0,
                0.0,
                core.time(),
                1.0
            )
        end)
        local sz = size_of_font(win, t.font_section, t.section_font_size, title)
        local ty = y + math.floor((head_h - sz.y) * 0.5)
        draw_text(win, t.font_section, vec2.new(x + 10, ty), t.text_header, title, t.section_font_size)
        win:render_line(vec2.new(x + 8, y + head_h), vec2.new(x + w - 8, y + head_h), t.border_panel, 1.0)
        return y + head_h + 8
    end
    return y + 10
end

function Menu:draw_status(win, x, y, w, h, title)
    local inner_y = self:draw_panel(win, x, y, w, h, title or "Status")
    local t = self.theme
    local row_h = 22
    local row_y = inner_y + 6
    for i = 1, #self.status_items do
        local item = self.status_items[i]
        if type(item) == "table" then
            local label = tostring(item.label or item.key or "")
            local value = call_value(item.value)
            local value_color = item.color
            if type(value_color) == "function" then
                value_color = safe(value_color)
            end
            if not value_color then
                value_color = t.text_primary
            end
            local label_sz = size_of_font(win, t.font_small, t.small_font_size, label)
            local value_sz = size_of_font(win, t.font_small, t.small_font_size, value)
            local ty = row_y + math.floor((row_h - label_sz.y) * 0.5)
            draw_text(win, t.font_small, vec2.new(x + 12, ty), t.text_secondary, label, t.small_font_size)
            draw_text(win, t.font_small, vec2.new(x + w - 14 - value_sz.x, ty), value_color, value, t.small_font_size)
            row_y = row_y + row_h
        end
    end
end

function Menu:draw_action(win, spec, x, y, w, h)
    local t = self.theme
    local style = spec.style or "neutral"
    local pmin = vec2.new(x, y)
    local pmax = vec2.new(x + w, y + h)
    local is_hover = hovered(win, pmin, pmax)
    local base = t.button_neutral
    local elev = t.button_neutral_hi
    local accent = t.border_panel
    if style == "start" or style == "primary" then
        base = t.button_start
        elev = t.button_start_hi
        accent = t.success
    elseif style == "pause" or style == "secondary" then
        base = t.button_pause
        elev = t.button_pause_hi
        accent = t.warning
    elseif style == "stop" or style == "danger" then
        base = t.button_stop
        elev = t.button_stop_hi
        accent = t.danger
    end
    local fill = is_hover and elev or base
    local painted = pcall(function()
        win:render_button_face(
            pmin,
            pmax,
            base,
            elev,
            accent,
            t.rounding,
            is_hover and 1.0 or 0.0,
            0.0,
            core.time(),
            1.0,
            1.0
        )
    end)
    if not painted then
        draw_rect(win, pmin, pmax, fill, accent, t.rounding, 1.0)
    end
    local label = spec.label or "Action"
    local sz = size_of_font(win, t.font_small, t.small_font_size, label)
    draw_text(win, t.font_small, vec2.new(x + math.floor((w - sz.x) * 0.5), y + math.floor((h - sz.y) * 0.5)), t.text_primary, label, t.small_font_size)
    block_drag(win, pmin, pmax)
    if clicked(win, pmin, pmax) then
        if type(spec.on_click) == "function" then
            pcall(spec.on_click)
        end
        return true
    end
    return false
end

function Menu:draw_actions(win, x, y, w)
    if type(self.actions) ~= "table" or #self.actions == 0 then
        return y
    end
    local t = self.theme
    local gap = 10
    local count = #self.actions
    local btn_w = math.floor((w - ((count - 1) * gap)) / count)
    local btn_h = t.button_height or 34
    local ax = x
    for i = 1, count do
        self:draw_action(win, self.actions[i], ax, y, btn_w, btn_h)
        ax = ax + btn_w + gap
    end
    return y + btn_h + 6
end

function Menu:draw_footer(win, m)
    local t = self.theme
    local y = m.h - m.footer_h
    local pmin = vec2.new(0, y)
    local pmax = vec2.new(m.w, m.h)
    draw_rect(win, pmin, pmax, t.bg_header, t.border_header, 0.0, t.border_thickness)
    local text = self.footer
    if text == "" then
        text = self.name .. "  v" .. tostring(self.version)
    end
    local sz = size_of_font(win, t.font_small, t.small_font_size, text)
    local tx = math.floor((m.w - sz.x) * 0.5)
    if tx < t.left_margin then
        tx = t.left_margin
    end
    local ty = y + math.floor((m.footer_h - sz.y) * 0.5)
    draw_text(win, t.font_small, vec2.new(tx, ty), t.text_secondary, text, t.small_font_size)
end

-- ---------------------------------------------------------------------------
-- Controls
-- ---------------------------------------------------------------------------

function Menu:draw_checkbox_row(win, record, x, y, width)
    local t = self.theme
    local on = resolve_bool(record.element)
    local h = t.row_height or 30
    local pmin = vec2.new(x, y)
    local pmax = vec2.new(x + width, y + h)
    local is_hover = hovered(win, pmin, pmax)
    local fill = t.bg_row
    local border = t.border_panel
    local text_col = t.text_off
    if on then
        fill = t.bg_tab_active
        border = t.accent
        text_col = t.text_on
    end
    if is_hover then
        fill = on and t.bg_tab_hover or t.bg_row_hover
    end
    draw_rect(win, pmin, pmax, fill, border, 3.0, 1.0)

    local stripe = on and t.text_on or t.text_off
    win:render_rect_filled(vec2.new(x, y), vec2.new(x + 3, y + h), stripe, 1.0)

    local box = 14
    local bx = x + 10
    local by = y + math.floor((h - box) * 0.5)
    draw_rect(win, vec2.new(bx, by), vec2.new(bx + box, by + box), on and t.accent or t.bg_input, border, 2.0, 1.0)
    if on then
        win:render_line(vec2.new(bx + 3, by + 7), vec2.new(bx + 6, by + 11), t.text_primary, 2.0)
        win:render_line(vec2.new(bx + 6, by + 11), vec2.new(bx + 11, by + 3), t.text_primary, 2.0)
    end

    local label_sz = size_of_font(win, t.font_small, t.small_font_size, record.label)
    local status = on and "ON" or "OFF"
    local status_sz = size_of_font(win, t.font_small, t.small_font_size, status)
    local ty = y + math.floor((h - label_sz.y) * 0.5)
    draw_text(win, t.font_small, vec2.new(bx + box + 10, ty), on and t.text_primary or t.text_secondary, record.label, t.small_font_size)
    draw_text(win, t.font_small, vec2.new(x + width - status_sz.x - 10, ty), text_col, status, t.small_font_size)

    if record.tooltip and is_hover then
        pcall(function()
            win:render_tooltip_text_only(record.tooltip, t.text_primary)
        end)
    end
    block_drag(win, pmin, pmax)
    if clicked(win, pmin, pmax) then
        set_bool(record.element, not on)
    end
    return y + h + t.control_gap
end

local function resolve_keybind_bool(elem)
    if not elem then
        return false
    end
    local state = safe(function()
        return elem:get_toggle_state()
    end)
    if type(state) == "boolean" then
        return state
    end
    return resolve_bool(elem)
end

function Menu:draw_keybind_row(win, record, x, y, width)
    local t = self.theme
    local elem = record.element
    local on = resolve_keybind_bool(elem)
    local code = 0
    if elem then
        local got = safe(function()
            return elem:get_key_code()
        end)
        if type(got) == "number" then
            code = got
        end
    end
    local h = t.row_height or 30
    local pmin = vec2.new(x, y)
    local pmax = vec2.new(x + width, y + h)
    local is_hover = hovered(win, pmin, pmax)
    local fill = t.bg_row
    local border = t.border_panel
    local text_col = t.text_off
    if on then
        fill = t.bg_tab_active
        border = t.accent
        text_col = t.text_on
    end
    if is_hover then
        fill = on and t.bg_tab_hover or t.bg_row_hover
    end
    draw_rect(win, pmin, pmax, fill, border, 3.0, 1.0)

    local stripe = on and t.text_on or t.text_off
    win:render_rect_filled(vec2.new(x, y), vec2.new(x + 3, y + h), stripe, 1.0)

    local key_name = key_display_name(code)
    local status = on and "ON" or "OFF"
    local label_sz = size_of_font(win, t.font_small, t.small_font_size, record.label)
    local status_sz = size_of_font(win, t.font_small, t.small_font_size, status)
    local key_sz = size_of_font(win, t.font_small, t.small_font_size, key_name)
    local ty = y + math.floor((h - label_sz.y) * 0.5)
    draw_text(win, t.font_small, vec2.new(x + 12, ty), on and t.text_primary or t.text_secondary, record.label, t.small_font_size)

    local pill_h = h - 10
    local pill_w = math.max(88, key_sz.x + 18)
    local pill_x = x + width - status_sz.x - 18 - pill_w
    local pill_y = y + math.floor((h - pill_h) * 0.5)
    local pill_min = vec2.new(pill_x, pill_y)
    local pill_max = vec2.new(pill_x + pill_w, pill_y + pill_h)
    local pill_ok = pcall(function()
        win:render_keybind_pill(
            pill_min,
            pill_max,
            t.bg_input,
            t.bg_tab_hover,
            on and t.accent or t.border_panel,
            4.0,
            is_hover and 1.0 or 0.0,
            0.0,
            core.time(),
            1.0
        )
    end)
    if not pill_ok then
        draw_rect(win, pill_min, pill_max, t.bg_input, on and t.accent or t.border_panel, 4.0, 1.0)
    end
    local key_ty = pill_y + math.floor((pill_h - key_sz.y) * 0.5)
    draw_text(win, t.font_small, vec2.new(pill_x + math.floor((pill_w - key_sz.x) * 0.5), key_ty), t.text_primary, key_name, t.small_font_size)
    draw_text(win, t.font_small, vec2.new(x + width - status_sz.x - 10, ty), text_col, status, t.small_font_size)

    local tip = record.tooltip
    if type(tip) ~= "string" or tip == "" then
        tip = "Click to toggle. Numpad keys also toggle this."
    end
    if is_hover then
        pcall(function()
            win:render_tooltip_text_only(tip, t.text_primary)
        end)
    end
    block_drag(win, pmin, pmax)
    if clicked(win, pmin, pmax) and elem then
        pcall(function()
            elem:set_toggle_state(not on)
        end)
    end
    return y + h + t.control_gap
end

function Menu:render_native_at(win, record, x, y, width)
    local element = record.element
    if not element then
        return y + 28
    end
    local row_h = 28
    local clipped = pcall(function()
        win:push_clip_rect(vec2.new(x, y), vec2.new(x + width, y + 48), true)
    end)
    pcall(function()
        win:begin_window_sub_context(vec2.new(x, y), true, function()
            pcall(function()
                win:set_next_widget_width(width or self.theme.control_width)
            end)
            if record.kind == "slider_int" or record.kind == "slider_float" then
                element:render(record.label, record.tooltip)
                return
            end
            if record.kind == "text_input" then
                element:render(record.label, record.tooltip)
                return
            end
            if record.kind == "combobox" then
                element:render(record.label, record.items or {}, record.tooltip)
                return
            end
            if record.kind == "button" then
                local pressed = element:render(record.label, record.tooltip)
                if pressed and type(record.on_click) == "function" then
                    pcall(record.on_click)
                end
            end
        end)
    end)
    if clipped then
        pcall(function()
            win:pop_clip_rect()
        end)
    end
    return y + row_h + self.theme.control_gap
end

function Menu:tab_content_height(tab_id)
    local t = self.theme
    local row = t.row_height or 35
    local gap = t.control_gap or 7
    local n = 0
    for i = 1, #self.order do
        if self.order[i].tab == tab_id then
            n = n + 1
        end
    end
    local h = 10 + n * (row + gap) + 10
    if self.tab_draw[tab_id] then
        h = h + row + 16
    end
    return h
end

function Menu:draw_scroll_thumb(win, tx, ty, tw, th, scroll, max_scroll, tab_id)
    if th < 8 then
        return scroll
    end
    local t = self.theme
    local track_min = vec2.new(tx, ty)
    local track_max = vec2.new(tx + tw, ty + th)
    draw_rect(win, track_min, track_max, t.bg_input, t.border_panel, 3.0, 1.0)

    local can_scroll = max_scroll >= 1
    if not can_scroll then
        max_scroll = 1
        scroll = 0
    end

    local thumb_h = math.floor(th * (th / (th + max_scroll)))
    if not can_scroll then
        thumb_h = th
    end
    if thumb_h < 22 then
        thumb_h = 22
    end
    if thumb_h > th then
        thumb_h = th
    end
    local travel = th - thumb_h
    local thumb_y = ty
    if travel > 0 then
        thumb_y = ty + math.floor(travel * (scroll / max_scroll))
    end
    local thumb_min = vec2.new(tx, thumb_y)
    local thumb_max = vec2.new(tx + tw, thumb_y + thumb_h)
    local is_hover = hovered(win, thumb_min, thumb_max) or hovered(win, track_min, track_max)
    draw_rect(win, thumb_min, thumb_max, is_hover and t.accent_hover or t.accent, t.border_header, 3.0, 1.0)

    local pressed = safe(function()
        return win:is_mouse_button_pressed(0)
    end) == true
    if not pressed then
        if self._scroll_drag == tab_id then
            self._scroll_drag = nil
        end
        block_drag(win, track_min, track_max)
        return scroll
    end

    local over = hovered(win, track_min, track_max) or self._scroll_drag == tab_id
    if over then
        self._scroll_drag = tab_id
        local mouse = safe(function()
            return win:get_mouse_pos_local()
        end)
        if mouse and type(mouse.y) == "number" and travel > 0 then
            local rel = (mouse.y - ty - (thumb_h * 0.5)) / travel
            if rel < 0 then
                rel = 0
            end
            if rel > 1 then
                rel = 1
            end
            scroll = rel * max_scroll
        end
    end
    block_drag(win, track_min, track_max)
    return scroll
end

function Menu:draw_tab_scroll_area(win, tab_id, x, y, w, h)
    local content_h = self:tab_content_height(tab_id)
    local bar_w = 8
    local view_w = w - bar_w - 4
    local max_scroll = math.max(0, content_h - h)
    local scroll = self._tab_scroll[tab_id] or 0

    local pmin = vec2.new(x, y)
    local pmax = vec2.new(x + w, y + h)
    block_drag(win, pmin, pmax)

    if hovered(win, pmin, pmax) and self._scroll_drag ~= tab_id then
        local wheel = safe(function()
            return core.get_mouse_wheel_delta()
        end)
        if type(wheel) == "number" and wheel ~= 0 then
            local step = wheel
            if math.abs(step) >= 10 then
                step = step / 120
            end
            scroll = scroll - (step * 36)
        end
    end

    if scroll < 0 then
        scroll = 0
    end
    if scroll > max_scroll then
        scroll = max_scroll
    end

    scroll = self:draw_scroll_thumb(win, x + w - bar_w, y, bar_w, h, scroll, max_scroll, tab_id) or scroll
    if scroll < 0 then
        scroll = 0
    end
    if scroll > max_scroll then
        scroll = max_scroll
    end
    self._tab_scroll[tab_id] = scroll

    local clipped = pcall(function()
        win:push_clip_rect(vec2.new(x, y), vec2.new(x + view_w, y + h), true)
    end)
    self:render_tab_controls(win, tab_id, x + 6, y + 6 - scroll, view_w - 12)
    if self.tab_draw[tab_id] then
        pcall(self.tab_draw[tab_id], win, x + 6, y + 6 - scroll, view_w - 12, h, self)
    end
    if clipped then
        pcall(function()
            win:pop_clip_rect()
        end)
    end
end

function Menu:render_tab_controls(win, tab_id, x, y, width)
    local cy = y
    for i = 1, #self.order do
        local record = self.order[i]
        if record.tab == tab_id then
            if record.kind == "checkbox" then
                cy = self:draw_checkbox_row(win, record, x, cy, width)
            elseif record.kind == "keybind" then
                cy = self:draw_keybind_row(win, record, x, cy, width)
            else
                cy = self:render_native_at(win, record, x, cy, width)
            end
        end
    end
    return cy
end

-- ---------------------------------------------------------------------------
-- Draw
-- ---------------------------------------------------------------------------

function Menu:set_visible(on)
    self.visible = on == true
    if self.visible then
        self._closed = false
    end
    pcall(function()
        self.window:set_visibility(self.visible)
    end)
end

function Menu:is_closed()
    return self._closed == true
end

function Menu:mark_closed()
    self.visible = false
    self._closed = true
    pcall(function()
        self.window:set_visibility(false)
    end)
    if type(self.on_close) == "function" then
        pcall(self.on_close)
    end
end

function Menu:handle_close_cross(win)
    local bounds = safe(function()
        return win:get_close_cross_bounds()
    end)
    if type(bounds) ~= "table" or not bounds.min or not bounds.max then
        return false
    end
    block_drag(win, bounds.min, bounds.max)
    if clicked(win, bounds.min, bounds.max) then
        self:mark_closed()
        return true
    end
    return false
end

function Menu:draw()
    local win = self.window
    if self.visible == false then
        pcall(function()
            win:set_visibility(false)
        end)
        return
    end

    self:retry_font()

    pcall(function()
        win:force_window_size(vec2.new(self.width, self.height))
    end)
    pcall(function()
        win:set_next_window_padding(vec2.new(0, 0))
    end)
    pcall(function()
        win:set_next_window_items_spacing(vec2.new(4, 2))
    end)

    local t = self.theme
    local open = win:begin(
        WE.window_resizing_flags.NO_RESIZE,
        true,
        t.bg_window,
        t.border_window,
        WE.window_cross_visuals.BLUE_THEME,
        function()
            if self:handle_close_cross(win) then
                return
            end
            local m = self:layout_metrics(win)
            self:draw_header(win, m)
            self:draw_nav(win, m)

            local active_id = self:active_tab()
            local tab_title = nil
            for i = 1, #self.tabs do
                if self.tabs[i].id == active_id then
                    tab_title = self.tabs[i].label
                    break
                end
            end

            local has_status = type(self.status_items) == "table" and #self.status_items > 0
            local gap = t.panel_gap
            local left_w = m.content_w
            local status_w = 0
            if has_status then
                status_w = math.floor(m.content_w * 0.38)
                left_w = m.content_w - status_w - gap
            end

            local left_x = m.content_x
            local left_y = m.content_y
            local panel_h = m.content_h
            if type(self.actions) == "table" and #self.actions > 0 then
                panel_h = panel_h - ((t.button_height or 34) + 12)
            end

            local inner_y = self:draw_panel(win, left_x, left_y, left_w, panel_h, tab_title)
            self:draw_tab_scroll_area(win, active_id, left_x + 8, inner_y + 4, left_w - 16, (left_y + panel_h) - inner_y - 10)

            if has_status then
                self:draw_status(win, left_x + left_w + gap, left_y, status_w, panel_h, "Status")
            end

            if type(self.actions) == "table" and #self.actions > 0 then
                self:draw_actions(win, left_x, left_y + panel_h + 6, m.content_w)
            end

            self:draw_footer(win, m)
        end
    )
    if open == false then
        self:mark_closed()
        return
    end
    local shown = safe(function()
        return win:is_being_shown()
    end)
    if shown == false then
        self:mark_closed()
    end
end

ui.Menu = Menu

return ui
