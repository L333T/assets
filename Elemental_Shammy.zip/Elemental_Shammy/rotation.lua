-- ============================================================================
-- Elemental_Shammy - ROTATION
-- ============================================================================
-- Author: BLIZZ
-- Version: 2.8
-- Folder: Elemental_Shammy_v2.8
-- Tick: wait for tank aggro on current enemy (skip if dummy/solo/BG) then AFK -> interrupt -> pots -> VE -> purge -> Gift -> Enlightenment LB -> LS -> heals -> totems -> drums -> mana pot -> EM/FS/CL/LB; moving shocks FS then ES then FrS
-- ============================================================================

---@type izi_api
local izi = require("common/izi_sdk")

---@type unit_helper
local unit_helper = require("common/utility/unit_helper")

local spells = require("spells")
local gui = require("gui")
local targeting = require("targeting")

local rotation = {}

local GCD_QUEUE_LEAD = 0.10
local HEAL_RANGE = 40.0
local PURGE_RANGE = 30.0
local INTERRUPT_RANGE = 20.0
local PURGE_MIN_MANA = 30
local PURGE_MIN_HP = 20
local PURGE_THROTTLE_S = 1.0
local INTERRUPT_MIN_ELAPSED_MS = 350
local INTERRUPT_LATE_REMAIN_MS = 1000
local INTERRUPT_TOO_LATE_MS = 80
local VIOLET_EYE_MANA = 75
local VIOLET_LOCK_S = 1.5
local GOTN_HP = 50
local HEALTHSTONE_HP = 70
local HEALTH_POTION_HP = 45
local MANA_POTION_PCT = 20

local HEAL_HW_HP = 25
local HEAL_LHW_HP = 35
local HEAL_CHAIN_HP = 50
local HEAL_CHAIN_COUNT = 2

local safe = spells.safe

local last_action = ""
local last_purge_guid = nil
local last_purge_time = 0.0
local violet_lock_until = 0.0

local function note_action(text)
    last_action = text
end

function rotation.last_action()
    return last_action
end

local function unit_alive(unit)
    if not unit then
        return false
    end
    if safe(function() return unit:is_valid() end) ~= true then
        return false
    end
    if safe(function() return unit:is_alive() end) == false then
        return false
    end
    if safe(function() return unit:is_dead() end) == true then
        return false
    end
    return true
end

local function in_combat(player)
    return safe(function() return player:is_in_combat() end) == true
end

local TANK_SCAN_RANGE = 80.0
-- game_object:get_group_role — NONE=-1, TANK=0, HEALER=1, DAMAGER=2
local GROUP_ROLE_TANK = 0
-- threat_table.status: 0 none, 1 higher than tank, 2 insecure tank, 3 secure aggro
local THREAT_SECURE = 3

local function guid_string(unit)
    if not unit then
        return nil
    end
    local guid = safe(function() return unit:get_guid() end)
    if guid == nil then
        guid = safe(function() return unit:guid() end)
    end
    if guid == nil then
        return nil
    end
    return tostring(guid)
end

local function same_unit(a, b)
    if not a or not b then
        return false
    end
    if a == b then
        return true
    end
    local ga = guid_string(a)
    local gb = guid_string(b)
    return ga ~= nil and ga == gb
end

local function unit_is_dummy(unit)
    if not unit then
        return false
    end
    if safe(function() return unit:is_dummy() end) == true then
        return true
    end
    return safe(function() return unit_helper:is_dummy(unit) end) == true
end

local function unit_is_tank(unit)
    if not unit_alive(unit) then
        return false
    end
    local role = safe(function() return unit:get_group_role() end)
    if role == GROUP_ROLE_TANK then
        return true
    end
    if safe(function() return unit_helper:is_tank(unit) end) == true then
        return true
    end
    if safe(function() return unit:is_tank() end) == true then
        return true
    end
    return false
end

---@param holder game_object
---@param other game_object
---@return boolean
local function threat_is_tanking(holder, other)
    if not holder or not other then
        return false
    end
    local data = safe(function()
        return holder:get_threat_situation(other)
    end)
    if type(data) ~= "table" then
        return false
    end
    if data.is_tanking == true then
        return true
    end
    return type(data.status) == "number" and data.status >= THREAT_SECURE
end

---True when the tank has aggro on this enemy (mob targeting tank, or secure threat).
---@param tank game_object
---@param enemy game_object
---@return boolean
local function tank_has_aggro_on(tank, enemy)
    if not tank or not enemy then
        return false
    end
    local mob_target = safe(function() return enemy:get_target() end)
    if same_unit(mob_target, tank) then
        return true
    end
    if threat_is_tanking(tank, enemy) then
        return true
    end
    if threat_is_tanking(enemy, tank) then
        return true
    end
    return false
end

local function collect_party_allies(player)
    local out = {}
    local seen = {}

    local function add(unit)
        if not unit or same_unit(unit, player) or not unit_alive(unit) then
            return
        end
        local guid = guid_string(unit)
        if guid then
            if seen[guid] then
                return
            end
            seen[guid] = true
        end
        out[#out + 1] = unit
    end

    local party = safe(function()
        return izi.party(TANK_SCAN_RANGE)
    end)
    if type(party) == "table" then
        for i = 1, #party do
            add(party[i])
        end
    end

    local nearby_party = safe(function()
        return player:get_party_members_in_range(TANK_SCAN_RANGE, true)
    end)
    if type(nearby_party) == "table" then
        for i = 1, #nearby_party do
            add(nearby_party[i])
        end
    end

    local pos = safe(function() return player:get_position() end)
    if pos then
        local allies = safe(function()
            return unit_helper:get_ally_list_around(pos, TANK_SCAN_RANGE, true, true)
        end)
        if type(allies) == "table" then
            for i = 1, #allies do
                add(allies[i])
            end
        end
    end

    return out
end

---True when it is safe to hit: dummy, solo, or a tank already has aggro on the current enemy.
---@param player game_object
---@param scan table|nil
---@return boolean
local function tank_combat_ready(player, scan)
    if safe(function() return unit_helper:is_player_in_bg() end) == true then
        return true
    end

    local enemy = scan and (scan.target or scan.focus) or nil
    if unit_is_dummy(enemy) then
        return true
    end

    local allies = collect_party_allies(player)
    if #allies == 0 then
        return true
    end

    if not enemy then
        return false
    end

    local tanks = {}
    for i = 1, #allies do
        if unit_is_tank(allies[i]) then
            tanks[#tanks + 1] = allies[i]
        end
    end

    if #tanks > 0 then
        for i = 1, #tanks do
            if tank_has_aggro_on(tanks[i], enemy) then
                return true
            end
        end
        return false
    end

    local mob_target = safe(function() return enemy:get_target() end)
    if not mob_target or same_unit(mob_target, player) then
        return false
    end
    for i = 1, #allies do
        if same_unit(mob_target, allies[i]) then
            return true
        end
    end
    return false
end

local function is_moving(player)
    return safe(function() return player:is_moving() end) == true
end

local function player_locked_out(player)
    if safe(function() return player:is_mounted() end) == true then
        return true
    end
    local silenced = safe(function() return player:is_silenced() end)
    if silenced == true then
        return true
    end
    local ccd = safe(function() return player:is_cc() end)
    if ccd == true then
        return true
    end
    local stunned = safe(function() return player:is_stunned() end)
    return stunned == true
end

local function is_busy_casting(player)
    local remaining = safe(function() return player:get_cast_remaining_sec() end)
    if type(remaining) == "number" and remaining > 0.05 then
        return true
    end
    if safe(function() return player:is_channeling() end) == true then
        return true
    end
    return false
end

local function on_global_cooldown(player)
    local remains = safe(function() return player:gcd_remains() end)
    if type(remains) == "number" and remains > GCD_QUEUE_LEAD then
        if spells.lightning_bolt and safe(function() return spells.lightning_bolt:in_gcd_window(GCD_QUEUE_LEAD) end) == true then
            return false
        end
        return true
    end
    return false
end

local function as_percent(raw)
    if type(raw) ~= "number" or raw < 0 then
        return nil
    end
    if raw <= 1 then
        return raw * 100.0
    end
    if raw <= 100 then
        return raw
    end
    return 100
end

local function health_pct(unit)
    local helper = as_percent(safe(function()
        return unit_helper:get_health_percentage(unit)
    end))
    if helper then
        return helper
    end

    local izi_pct = as_percent(safe(function()
        return unit:get_health_percentage()
    end))
    if izi_pct then
        return izi_pct
    end

    return 100
end

local function predicted_health_pct(unit)
    local future_hp = safe(function()
        local fut = unit:get_health_percentage_inc(2.0)
        return fut
    end)
    if type(future_hp) == "number" and future_hp >= 0 then
        return as_percent(future_hp) or future_hp
    end
    return health_pct(unit)
end

local function mana_pct(player)
    local current = safe(function() return player:mana_current() end)
    local maximum = safe(function() return player:mana_max() end)
    if type(current) == "number" and type(maximum) == "number" and maximum > 0 then
        return (current / maximum) * 100.0
    end

    local raw = safe(function() return player:mana_pct() end)
    if type(raw) == "number" and raw >= 0 then
        if raw > 0 and raw <= 1 then
            return raw * 100.0
        end
        return raw
    end
    return 100
end

local function unit_guid(unit)
    if not unit then
        return nil
    end
    local guid = safe(function() return unit:get_guid() end)
    if guid == nil then
        guid = safe(function() return unit:guid() end)
    end
    if guid == nil then
        return nil
    end
    return tostring(guid)
end

local function is_interruptible(unit)
    if not unit_alive(unit) then
        return false
    end
    if safe(function() return unit:is_channeling_or_casting() end) ~= true then
        if safe(function() return unit:is_casting() end) ~= true then
            if safe(function() return unit:is_casting_spell() end) ~= true then
                if safe(function() return unit:is_channeling() end) ~= true then
                    return false
                end
            end
        end
    end
    return safe(function() return unit:is_active_spell_interruptable() end) == true
end

local function interrupt_window_open(unit)
    local remaining_ms = safe(function() return unit:get_channeling_or_casting_remaining_ms() end)
    if type(remaining_ms) == "number" and remaining_ms > 0 and remaining_ms <= INTERRUPT_TOO_LATE_MS then
        return false
    end

    if safe(function() return unit:is_channeling() end) == true then
        local channel_elapsed = safe(function() return unit:get_channel_elapsed_ms() end)
        if type(channel_elapsed) == "number" and channel_elapsed >= 150 then
            return true
        end
        local pct = safe(function() return unit:get_channeling_or_casting_pct() end)
        if type(pct) == "number" and pct >= 15 then
            return true
        end
        return false
    end

    if type(remaining_ms) == "number" and remaining_ms > 0 and remaining_ms <= INTERRUPT_LATE_REMAIN_MS then
        return true
    end

    local cast_pct = safe(function() return unit:get_channeling_or_casting_pct() end)
    if type(cast_pct) == "number" and cast_pct >= 35 then
        return true
    end

    local elapsed_ms = safe(function() return unit:get_cast_elapsed_ms() end)
    if type(elapsed_ms) ~= "number" then
        local start_time = safe(function() return unit:get_active_spell_cast_start_time() end)
        if type(start_time) == "number" then
            elapsed_ms = (core.time() - start_time) * 1000.0
        else
            elapsed_ms = INTERRUPT_MIN_ELAPSED_MS
        end
    end

    return elapsed_ms >= INTERRUPT_MIN_ELAPSED_MS
end

local function run_interrupt(player, scan)
    if not gui.is_on("interrupt") then
        return false
    end
    if not spells.earth_shock_r1 then
        return false
    end

    local gcd_remains = safe(function() return player:gcd_remains() end)
    if type(gcd_remains) == "number" and gcd_remains > GCD_QUEUE_LEAD then
        return false
    end

    local ready = safe(function() return spells.earth_shock_r1:cooldown_up() end)
    if ready ~= true then
        return false
    end

    local shock_opts = {
        skip_casting = true,
        skip_channeling = true,
        skip_moving = true,
    }

    local target_candidate = safe(function()
        return izi.pick_enemy(INTERRUPT_RANGE, false, function(unit)
            if not unit_alive(unit) or targeting.should_avoid(unit) then
                return nil
            end
            if not targeting.has_los(player, unit) then
                return nil
            end
            if not is_interruptible(unit) or not interrupt_window_open(unit) then
                return nil
            end
            local rem = unit:get_channeling_or_casting_remaining_ms()
            return (type(rem) == "number" and rem > 0) and rem or 9999
        end, "min")
    end)

    if target_candidate then
        local castable = safe(function()
            return spells.earth_shock_r1:is_castable_to_unit(target_candidate, shock_opts)
        end)
        if castable == true or is_busy_casting(player) then
            if spells.cast_earth_shock_interrupt(target_candidate) then
                note_action("Earth Shock (interrupt)")
                return true
            end
        end
    end

    return false
end

local function purge_recently(unit)
    local guid = unit_guid(unit)
    if not guid or guid ~= last_purge_guid then
        return false
    end
    return (core.time() - last_purge_time) < PURGE_THROTTLE_S
end

local function can_spend_purge_mana(player)
    return mana_pct(player) > PURGE_MIN_MANA
end

local function purge_score(player, unit)
    if not unit_alive(unit) then
        return nil
    end
    if not targeting.in_range(player, unit, PURGE_RANGE) then
        return nil
    end
    if not targeting.has_los(player, unit) then
        return nil
    end
    if health_pct(unit) <= PURGE_MIN_HP then
        return nil
    end
    if spells.is_trivial_purge_unit(unit) then
        return nil
    end
    if purge_recently(unit) then
        return nil
    end

    local pri = spells.unit_purge_priority(unit)
    if pri <= 0 then
        return nil
    end

    local score = pri * 10
    if spells.is_humanoid_or_undead(unit) then
        score = score + 5
    end
    if safe(function() return unit:is_channeling_or_casting() end) == true then
        score = score + 3
    end
    return score
end

local function pick_purge_target(player, scan)
    local focus = scan and (scan.target or scan.focus) or nil
    if focus and purge_score(player, focus) then
        return focus
    end

    local best_target = safe(function()
        return izi.pick_enemy(PURGE_RANGE, false, function(unit)
            return purge_score(player, unit)
        end, "max")
    end)
    if best_target then
        return best_target
    end

    return nil
end

local function run_purge(player, scan)
    if not gui.is_on("purge") then
        return false
    end
    if not spells.purge then
        return false
    end
    if not can_spend_purge_mana(player) then
        return false
    end

    local gcd_remains = safe(function() return player:gcd_remains() end)
    if type(gcd_remains) == "number" and gcd_remains > GCD_QUEUE_LEAD then
        return false
    end

    local victim = pick_purge_target(player, scan)
    if not victim then
        return false
    end

    local purge_opts = {
        skip_casting = true,
        skip_channeling = true,
        skip_moving = true,
    }
    local castable = safe(function()
        return spells.purge:is_castable_to_unit(victim, purge_opts)
    end)
    if castable ~= true and not is_busy_casting(player) then
        return false
    end

    if spells.cast_purge(victim) then
        last_purge_guid = unit_guid(victim)
        last_purge_time = core.time()
        note_action("Purge")
        return true
    end

    return false
end

---Master Healthstone (22105) when player health is below 70%, then best health potion below 45%.
---@param player game_object
---@return boolean
local function run_healthstone_and_potions(player)
    local hp = health_pct(player)
    if hp >= HEALTHSTONE_HP then
        return false
    end
    if spells.player_is_eating_or_drinking(player) then
        return false
    end
    if spells.healthstone_ready(player) then
        if spells.use_healthstone(player) then
            note_action("Master Healthstone")
            return true
        end
    end
    if hp <= HEALTH_POTION_HP then
        if spells.use_best_health_potion(player) then
            note_action("Healing Potion")
            return true
        end
    end
    return false
end

---Keep Lightning Shield up. Never recast while eating or drinking.
---@param player game_object
---@return boolean
local function maintain_shield(player)
    if spells.player_is_eating_or_drinking(player) then
        return false
    end
    if spells.player_has_lightning_shield(player) then
        return false
    end
    if on_global_cooldown(player) then
        return true
    end
    if spells.cast_self(spells.lightning_shield, player, "Lightning Shield", { skip_moving = true }) then
        note_action("Lightning Shield")
        return true
    end
    return false
end

---Draenei racial Gift of the Naaru (28880). Instant HoT, 3 minute cooldown.
---@param player game_object
---@return boolean
local function run_gift_of_the_naaru(player)
    if health_pct(player) > GOTN_HP then
        return false
    end
    if not spells.spell_is_learned(spells.gift_of_the_naaru, spells.ids.gift_of_the_naaru) then
        return false
    end
    if spells.player_has_gift_of_the_naaru(player) then
        return false
    end

    local spell = spells.gift_of_the_naaru
    if not spell then
        return false
    end

    local ready = safe(function() return spell:cooldown_up() end)
    if ready ~= true then
        return false
    end

    local gcd_remains = safe(function() return player:gcd_remains() end)
    if type(gcd_remains) == "number" and gcd_remains > GCD_QUEUE_LEAD then
        return false
    end

    if is_busy_casting(player) then
        spells.stop_casting()
    end

    if spells.cast_self(spell, player, "Gift of the Naaru", {
        skip_moving = true,
        skip_casting = true,
        skip_channeling = true,
    }) then
        note_action("Gift of the Naaru")
        return true
    end
    return false
end

---Clear AFK via core.input.clear_afk while the AFK toggle is on.
local function run_afk()
    if not gui.is_on("afk") then
        return
    end
    pcall(function()
        core.input.clear_afk()
    end)
end

local function collect_heal_candidates(player)
    local candidates = { player }
    local seen = {}
    local p_guid = unit_guid(player)
    if p_guid then
        seen[p_guid] = true
    end

    local friends = safe(function()
        return izi.friends_if(HEAL_RANGE, function(u)
            return unit_alive(u) and safe(function() return u:is_valid_ally() end) == true
        end)
    end)
    if type(friends) ~= "table" then
        friends = safe(function() return izi.party(HEAL_RANGE) end)
    end

    if type(friends) == "table" then
        for i = 1, #friends do
            local ally = friends[i]
            local guid = unit_guid(ally)
            if ally ~= player and unit_alive(ally) and (not guid or not seen[guid]) then
                if guid then
                    seen[guid] = true
                end
                candidates[#candidates + 1] = ally
            end
        end
    end
    return candidates
end

local function lowest_and_injured_predicted(candidates, threshold)
    local lowest = nil
    local lowest_hp = 101
    local injured = 0

    for i = 1, #candidates do
        local unit = candidates[i]
        local hp = predicted_health_pct(unit)
        if hp <= threshold then
            injured = injured + 1
        end
        if hp < lowest_hp then
            lowest_hp = hp
            lowest = unit
        end
    end

    return lowest, lowest_hp, injured
end

local function run_healing(player)
    if not gui.is_on("heal") then
        return false
    end

    local candidates = collect_heal_candidates(player)
    local lowest, lowest_hp, injured_chain = lowest_and_injured_predicted(candidates, HEAL_CHAIN_HP)
    if not lowest then
        return false
    end

    -- Priority 1: Heavy emergency heal (HW) when very low (< 25%) and standing
    if (not is_moving(player)) and lowest_hp <= HEAL_HW_HP then
        if spells.cast_unit(spells.healing_wave, lowest, "Healing Wave") then
            note_action("Healing Wave")
            return true
        end
    end

    -- Priority 2: Fast triage heal (LHW) when low (< 35%)
    if lowest_hp <= HEAL_LHW_HP then
        if spells.cast_unit(spells.lesser_healing_wave, lowest, "Lesser Healing Wave") then
            note_action("Lesser Healing Wave")
            return true
        end
    end

    -- Priority 3: Group triage heal (Chain Heal) when multiple injured
    if (not is_moving(player)) and injured_chain >= HEAL_CHAIN_COUNT then
        if spells.cast_unit(spells.chain_heal, lowest, "Chain Heal") then
            note_action("Chain Heal")
            return true
        end
    end

    return false
end

local function maintain_combat_totems(player, scan)
    if not scan.in_cast_range and not scan.target and not scan.focus then
        return false
    end

    if spells.totem_needs_recast(player, { 307308, 30708 }, spells.totem_of_wrath, "Totem of Wrath") then
        if spells.place_totem(spells.totem_of_wrath, player, "totem_of_wrath", "Totem of Wrath") then
            note_action("Totem of Wrath")
            return true
        end
    end

    if spells.totem_needs_recast(player, spells.ids.wrath_of_air_buff, spells.wrath_of_air, "Wrath of Air Totem") then
        if spells.place_totem(spells.wrath_of_air, player, "wrath_of_air", "Wrath of Air Totem") then
            note_action("Wrath of Air Totem")
            return true
        end
    end

    if spells.totem_needs_recast(player, spells.ids.mana_spring_buff, spells.mana_spring, "Mana Spring Totem") then
        if spells.place_totem(spells.mana_spring, player, "mana_spring", "Mana Spring Totem") then
            note_action("Mana Spring Totem")
            return true
        end
    end

    if spells.totem_needs_recast(player, nil, spells.tremor, "Tremor Totem") then
        if spells.place_totem(spells.tremor, player, "tremor", "Tremor Totem") then
            note_action("Tremor Totem")
            return true
        end
    end

    return false
end

local function run_drums(player, scan)
    if not gui.is_on("drums") then
        return false
    end
    if not spells.combat_totems_ready(player) then
        return false
    end
    local victim = scan.target or scan.focus
    if not victim then
        return false
    end
    if health_pct(victim) <= 30 then
        return false
    end
    if spells.unit_time_to_die(victim) < 20 and not scan.has_boss then
        return false
    end
    if spells.use_drums(player) then
        note_action("Drums of Battle")
        return true
    end
    return false
end

local function run_mana_potion(player)
    if not in_combat(player) then
        return false
    end
    if mana_pct(player) >= MANA_POTION_PCT then
        return false
    end
    if spells.use_best_mana_potion(player) then
        note_action("Mana Potion")
        return true
    end
    return false
end

local function enlightenment_active(player)
    if not gui.is_on("trinket_ve") then
        violet_lock_until = 0.0
        return false
    end
    if spells.player_has_enlightenment(player) then
        return true
    end
    return core.time() < violet_lock_until
end

---Trinket is wanted, equipped, and still off cooldown.
---@param player game_object
---@param scan table|nil
---@return boolean
local function violet_eye_should_use(player, scan)
    if not gui.is_on("trinket_ve") then
        return false
    end
    if spells.player_has_enlightenment(player) then
        return false
    end
    if mana_pct(player) >= VIOLET_EYE_MANA then
        return false
    end
    if not in_combat(player) then
        return false
    end
    if not scan or not scan.in_cast_range or not unit_alive(scan.target) then
        return false
    end
    return spells.violet_eye_ready(player)
end

---Use the trinket and hold the tick. True means do not resume other rotation.
---@param player game_object
---@param scan table|nil
---@return boolean
local function run_violet_eye(player, scan)
    if not violet_eye_should_use(player, scan) then
        return false
    end

    if spells.use_violet_eye(player) then
        last_action = "Pendant of the Violet Eye"
        if spells.player_has_enlightenment(player) or not spells.violet_eye_ready(player) then
            violet_lock_until = core.time() + VIOLET_LOCK_S
        end
    end

    return true
end

local function run_enlightenment_lb(player, target)
    if not unit_alive(target) then
        return false
    end
    if is_moving(player) then
        return false
    end
    if spells.cast_unit(spells.lightning_bolt, target, "Lightning Bolt") then
        note_action("Lightning Bolt (Enlightenment)")
        return true
    end
    return false
end

local function run_elemental_mastery(player)
    if not in_combat(player) then
        return false
    end

    local spell = spells.elemental_mastery
    if not spell then
        return false
    end
    if spells.has_player_buff(player, spells.ids.elemental_mastery_buff) then
        return false
    end

    local ready = safe(function() return spell:cooldown_up() end)
    if ready ~= true then
        return false
    end

    local opts = { skip_range = true, skip_facing = true }
    local skips = safe(function() return spell:skips_gcd() end)
    if skips == true then
        opts.skip_gcd = true
    end

    if spells.cast_self(spell, player, "Elemental Mastery", opts) then
        note_action("Elemental Mastery")
        return true
    end
    return false
end

local SHOCK_OPTS = {
    skip_moving = true,
}

local function shock_ready(spell)
    if not spell then
        return false
    end
    return safe(function() return spell:cooldown_up() end) == true
end

local function cast_shock(spell, target, message)
    if not shock_ready(spell) then
        return false
    end
    if spells.cast_unit(spell, target, message, SHOCK_OPTS) then
        note_action(message)
        return true
    end
    return false
end

---Moving filler: Flame Shock refresh, then Earth Shock 25454, then Frost Shock 25464.
---@param player game_object
---@param target game_object
---@return boolean
local function run_moving_shocks(player, target)
    if not is_moving(player) then
        return false
    end
    if not unit_alive(target) then
        return false
    end

    if gui.is_on("flame_shock") then
        local ttd = spells.unit_time_to_die(target)
        if ttd >= 6 and spells.flame_shock_needs_refresh(target) then
            if cast_shock(spells.flame_shock, target, "Flame Shock") then
                return true
            end
        end
    end

    if gui.is_on("earth_shock") then
        if cast_shock(spells.earth_shock, target, "Earth Shock") then
            return true
        end
    end

    if gui.is_on("frost_shock") then
        if cast_shock(spells.frost_shock, target, "Frost Shock") then
            return true
        end
    end

    return false
end

local function run_damage(player, target)
    if not unit_alive(target) then
        return false
    end

    if run_elemental_mastery(player) then
        return true
    end

    if is_moving(player) then
        return run_moving_shocks(player, target)
    end

    if gui.is_on("flame_shock") then
        local ttd = spells.unit_time_to_die(target)
        if ttd >= 6 and spells.flame_shock_needs_refresh(target) then
            if cast_shock(spells.flame_shock, target, "Flame Shock") then
                return true
            end
        end
    end

    if gui.is_on("chain") then
        local cl_ready = safe(function() return spells.chain_lightning:cooldown_up() end)
        if cl_ready == true then
            local splash_count = safe(function()
                return target:get_enemies_in_splash_range_count(10)
            end)
            if type(splash_count) ~= "number" or splash_count >= 2 then
                if spells.cast_unit(spells.chain_lightning, target, "Chain Lightning") then
                    note_action("Chain Lightning")
                    return true
                end
            end
        end
    end

    if spells.cast_unit(spells.lightning_bolt, target, "Lightning Bolt") then
        note_action("Lightning Bolt")
        return true
    end

    return false
end

function rotation.tick()
    if not gui.is_on("enable") then
        return
    end

    local player = safe(function() return izi.me() end)
    if not unit_alive(player) then
        return
    end

    if player_locked_out(player) then
        return
    end

    run_afk()

    local scan = targeting.update(player)
    local can_attack = tank_combat_ready(player, scan)

    if can_attack then
        if run_interrupt(player, scan) then
            return
        end
    end

    if run_healthstone_and_potions(player) then
        return
    end

    if can_attack then
        if run_violet_eye(player, scan) then
            return
        end

        if run_purge(player, scan) then
            return
        end
    end

    if run_gift_of_the_naaru(player) then
        return
    end

    if can_attack and enlightenment_active(player) then
        if is_busy_casting(player) then
            return
        end
        if on_global_cooldown(player) then
            return
        end
        if scan.in_cast_range then
            run_enlightenment_lb(player, scan.target)
        end
        return
    end

    if is_busy_casting(player) then
        return
    end

    if maintain_shield(player) then
        return
    end

    if can_attack and on_global_cooldown(player) then
        run_elemental_mastery(player)
        return
    end

    if run_healing(player) then
        return
    end

    if not scan.in_cast_range then
        return
    end

    if maintain_combat_totems(player, scan) then
        return
    end

    if not can_attack then
        return
    end

    if run_drums(player, scan) then
        return
    end

    run_mana_potion(player)

    run_damage(player, scan.target)
end

return rotation
