-- ============================================================================
-- Elemental_Shammy - TBC Elemental Shaman (Standalone IZI)
-- ============================================================================
-- Purpose: Plugin load gate. IZI only. No FB_Nexus.
-- Author: BLIZZ
-- Version: 2.8
-- Folder: Elemental_Shammy_v2.8
-- ============================================================================

local plugin = {}
plugin["name"]    = "Elemental_Shammy"
plugin["version"] = "2.8"
plugin["author"]  = "BLIZZ"
plugin["load"]    = true

local local_player = core.object_manager.get_local_player()
if not local_player then
    plugin["load"] = false
    return plugin
end

---@type enums
local enums = require("common/enums")

if local_player:get_class() ~= enums.class_id.SHAMAN then
    plugin["load"] = false
    return plugin
end

local izi_ok, izi = pcall(require, "common/izi_sdk")
if (not izi_ok) or type(izi) ~= "table" then
    core.log_error("[Elemental_Shammy] common/izi_sdk is unavailable - plugin not loaded.")
    plugin["load"] = false
    return plugin
end

local required_izi = {
    "on_update",
    "spell",
    "item",
    "enemies",
    "party",
    "me",
    "now",
}

local missing = {}
for i = 1, #required_izi do
    local field = required_izi[i]
    if type(izi[field]) ~= "function" then
        missing[#missing + 1] = field
    end
end

if #missing > 0 then
    core.log_error("[Elemental_Shammy] izi_sdk is missing required entry points: " .. table.concat(missing, ", "))
    plugin["load"] = false
    return plugin
end

_G.Elemental_Shammy = _G.Elemental_Shammy or {}
local NS = _G.Elemental_Shammy

NS.meta = {
    name    = plugin["name"],
    version = plugin["version"],
    author  = plugin["author"],
}

NS.session = (NS.session or 0) + 1

return plugin
